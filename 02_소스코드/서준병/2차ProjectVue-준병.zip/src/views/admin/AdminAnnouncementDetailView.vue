<template>
  <h3>공지사항</h3>
  <hr />

  <br />
  <br />

  <h3>공지사항 상세 조회</h3>
  <hr />

  <!-- TODO : div에 v-model 써서 작성자, 등록날짜 넣기 -->
  <div class="container text-center">
    <div class="row">
      <div class="col">작성자</div>
      <div class="col">등록 날짜</div>      
    </div>
  </div>

  <hr />

  <div class="mb-3">
    <!-- TODO : div에 v-model 써서 제목 넣기 -->
    <div class="fs-3 text-center">예시 제목입니다!</div>
  </div>
  <hr />

  <!-- TODO : div에 v-model 써서 사진데이터 넣기 -->
  <div class="text-center">
    <img
      src="https://cdn.pixabay.com/photo/2017/08/06/00/44/korean-2587180_1280.jpg"
      alt=""
    />
  </div>
  <hr />
  <br />

  <div class="mb-3">
    <!-- TODO : div에 v-model 써서 내용 넣기 -->
    <div class="fs-4">
      예시 내용 입니다 Lorem ipsum dolor sit, amet consectetur adipisicing elit.
      Possimus, corporis placeat harum voluptatem qui officiis. Qui modi odit
      aut excepturi hic placeat odio. Ducimus est officia repellat, eius minima
      ullam?
    </div>
  </div>
  <hr />

  <br />

  <div class="text-center">
    <a href=""><button type="button" class="btn btn-primary me-2">수정</button></a>
    <a href="#"><button type="button" class="btn btn-danger me-2">삭제</button></a>
    <a href="/AdminAnouncement"
      ><button type="button" class="btn btn-secondary">확인/뒤로가기</button></a
    >
  </div>

  <br />
  <br />
</template>
<script>
export default {};
</script>
<style></style>
