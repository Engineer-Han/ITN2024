<template>
  <h3>상품 관리</h3>
  <hr />

  <br />
  <br />

  <h3>상품 등록 수정</h3>
  <hr />

  <div class="mb-3">
    <label class="form-label"> 상품명</label>
    <input
      type="text"
      class="form-control"
      placeholder="상품명을 적어주세요"
      v-model="products.name"
    />
  </div>

  <br />

  <!-- 데이터베이스에서 어떻게 불러올지 의논하기 -->
  <div class="mb-3">
    <label for="exampleFormControlTextarea1" class="form-label">카테고리</label>
    <select
      class="form-select"
      aria-label="Default select example"
      v-model="products.karegorie"
    >
      <option selected>제품 카테고리를 선택하세요</option>
      <option value="1">두루마기, 도포</option>
      <option value="2">저고리</option>
      <option value="3">바지, 치마</option>
    </select>
  </div>

  <br />

  <!-- 데이터베이스에서 어떻게 불러올지 의논하기 -->
  <div class="mb-3">
    <label for="exampleFormControlTextarea1" class="form-label"
      >성별(Sex)</label
    >
    <select class="form-select" aria-label="Default select example">
      <option selected>제품 성별 카테고리를 선택하세요</option>
      <option value="1">남성</option>
      <option value="2">여성</option>
      <option value="3">남녀공용</option>
    </select>
  </div>

  <br />

  <div class="mb-3">
    <label for="exampleFormControlTextarea1" class="form-label"
      >단일 가격 지정</label
    >
    <input
      class="form-control"
      type="number"
      placeholder="가격 지정을 해주세요"
      aria-label="default input example"
      v-model="products.price"
    />
  </div>

  <div class="mb-3">
    <label for="exampleFormControlTextarea1" class="form-label">상세내용</label>
    <textarea
      class="form-control"
      id="exampleFormControlTextarea1"
      rows="3"
      v-model="products.contents"
    ></textarea>
  </div>

  <br />
  <!-- 사진 파일 입력 -->
  <h3>메인 사진 (페이지 상단)</h3>
  <hr />
  <label for="exampleFormControlTextarea1" class="form-label">메인 사진</label>
  <div class="input-group">
    <input
      type="file"
      class="form-control"
      aria-describedby="inputGroupFileAddon04"
      aria-label="Upload"
    />
    <button
      class="btn btn-outline-secondary"
      type="button"
      id="inputGroupFileAddon04"
    >
      파일 불러오기
    </button>
  </div>
  <br />

  <label for="exampleFormControlTextarea1" class="form-label"
    >메인 서브 사진 2개</label
  >
  <div class="input-group">
    <input
      type="file"
      class="form-control"
      aria-describedby="inputGroupFileAddon04"
      aria-label="Upload"
    />
    <button
      class="btn btn-outline-secondary"
      type="button"
      id="inputGroupFileAddon04"
    >
      파일 불러오기
    </button>
  </div>
  <br />
  <div class="input-group">
    <input
      type="file"
      class="form-control"
      aria-describedby="inputGroupFileAddon04"
      aria-label="Upload"
    />
    <button
      class="btn btn-outline-secondary"
      type="button"
      id="inputGroupFileAddon04"
    >
      파일 불러오기
    </button>
  </div>

  <br />
  <br />

  <h3>상세 사진 (이미지 하단)</h3>
  <hr />
  <label for="exampleFormControlTextarea1" class="form-label"
    >상세사진 8개</label
  >
  <div class="input-group">
    <input
      type="file"
      class="form-control"
      aria-describedby="inputGroupFileAddon04"
      aria-label="Upload"
    />
    <button
      class="btn btn-outline-secondary"
      type="button"
      id="inputGroupFileAddon04"
    >
      파일 불러오기
    </button>
  </div>
  <br />

  <div class="input-group">
    <input
      type="file"
      class="form-control"
      aria-describedby="inputGroupFileAddon04"
      aria-label="Upload"
    />
    <button
      class="btn btn-outline-secondary"
      type="button"
      id="inputGroupFileAddon04"
    >
      파일 불러오기
    </button>
  </div>
  <br />

  <div class="input-group">
    <input
      type="file"
      class="form-control"
      aria-describedby="inputGroupFileAddon04"
      aria-label="Upload"
    />
    <button
      class="btn btn-outline-secondary"
      type="button"
      id="inputGroupFileAddon04"
    >
      파일 불러오기
    </button>
  </div>
  <br />

  <div class="input-group">
    <input
      type="file"
      class="form-control"
      aria-describedby="inputGroupFileAddon04"
      aria-label="Upload"
    />
    <button
      class="btn btn-outline-secondary"
      type="button"
      id="inputGroupFileAddon04"
    >
      파일 불러오기
    </button>
  </div>
  <br />

  <div class="input-group">
    <input
      type="file"
      class="form-control"
      aria-describedby="inputGroupFileAddon04"
      aria-label="Upload"
    />
    <button
      class="btn btn-outline-secondary"
      type="button"
      id="inputGroupFileAddon04"
    >
      파일 불러오기
    </button>
  </div>
  <br />

  <div class="input-group">
    <input
      type="file"
      class="form-control"
      aria-describedby="inputGroupFileAddon04"
      aria-label="Upload"
    />
    <button
      class="btn btn-outline-secondary"
      type="button"
      id="inputGroupFileAddon04"
    >
      파일 불러오기
    </button>
  </div>
  <br />

  <div class="input-group">
    <input
      type="file"
      class="form-control"
      aria-describedby="inputGroupFileAddon04"
      aria-label="Upload"
    />
    <button
      class="btn btn-outline-secondary"
      type="button"
      id="inputGroupFileAddon04"
    >
      파일 불러오기
    </button>
  </div>
  <br />

  <div class="input-group">
    <input
      type="file"
      class="form-control"
      aria-describedby="inputGroupFileAddon04"
      aria-label="Upload"
    />
    <button
      class="btn btn-outline-secondary"
      type="button"
      id="inputGroupFileAddon04"
    >
      파일 불러오기
    </button>
  </div>
  <br />

  <br />
  <br />

  <div class="text-center">
    <button type="button" class="btn btn-primary me-2" @click="update">
      수정
    </button>
    <a href="/AdminMerchandise"
      ><button type="button" class="btn btn-warning">취소</button></a
    >
  </div>
  <br />
  <br />
  <br />
</template>
<script>
import ProductService from "@/services/basic/ProductService";
export default {
  data() {
    return {
      products: {
        prid: this.$route.params.prid,
        code: "",
        name: "",
        karegorie: "",
        gender: "",
        price: "",
        contents: "",
        image: undefined,
        titleImageUrl: "",
        detailImageurl2: "",
        detailImageurl3: "",
        detailImageurl4: "",
        detailImageurl5: "",
        detailImageurl6: "",
        detailImageurl7: "",
        detailImageurl8: "",
        detailImageurl9: "",
        detailImageurl10: "",
        detailImageurl11: "",
        inserTime: "",
        updateTime: "",
      },
    };
  },
  methods: {
    async getDetail(prid) {
      try {
        let response = await ProductService.get(prid);
        console.log(response.data);
        this.products = response.data;
      } catch (error) {
        console.log(error);
      }
    },
    select() {
      this.products.image = this.$refs.file.files[0];
    },
    async update() {
      try {
        let response = await ProductService.update(
          this.products.noid,
          this.products
        );
        console.log(response.data);
        this.products = response.data;
        alert("수정되었습니다");
        this.$router.push("/AdminAnouncement");
      } catch (error) {
        this.products.image = undefined;
        console.log(error);
      }
    },
  },
  mounted() {
    this.getDetail(this.$route.params.prid);
  },
};
</script>
<style></style>
