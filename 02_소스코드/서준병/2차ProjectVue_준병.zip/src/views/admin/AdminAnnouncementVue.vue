<template lang="">
  <h3>공지사항</h3>
  <hr />

  <br />
  <br />

  <h3>검색</h3>
  <br />

  <table class="table table-bordered table-sm">
    <tbody>
      <tr>
        <th scope="row">검색어</th>
        <td>
          <div class="row align-items-center">
            <div class="col-auto">
              <select
                class="form-select form-select"
                style="width: 200px"
                aria-label=".form-select example"
              >
                <option selected>검색어 선택</option>
                <option value="1">제목</option>
                <option value="2">작성일</option>
              </select>
            </div>
            <div class="col">
              <input
                type="text"
                class="form-control"
                placeholder="검색어를 입력하세요"
              />
            </div>
          </div>
        </td>
      </tr>
    </tbody>
  </table>

  <div class="text-center">
    <button type="button" class="btn btn-primary btn-sm me-2">검색</button>
    <button type="button" class="btn btn-secondary btn-sm">초기화</button>
  </div>

  <br />
  <br />

  <div class="row">
    <div class="col">
      <p class="fs-3 text">공지사항 리스트</p>
    </div>
    <div class="col">
      <p class="d-grid gap-2 d-md-flex justify-content-md-end">
        <a href="/AdminAnouncementAdd">
          <button class="btn btn-primary me-md-2" type="button">
            등록하기
          </button></a
        >
      </p>
    </div>
  </div>

  <hr />

  <table class="table">
    <thead>
      <tr class="table-secondary">
        <th scope="col">번호</th>
        <th scope="col">제목</th>
        <th scope="col">작성자</th>
        <th scope="col">작성일</th>
        <th scope="col">수정일</th>
      </tr>
    </thead>
    <tbody>
      <tr v-for="(data, index) in notices" :key="index">
        <td>{{ calculateIndex(index) }}</td>
        <td>
          <router-link :to="'/AdminAnouncement/' + data.noid">{{
            data.title
          }}</router-link>
        </td>
        <td>{{ data.writer }}</td>
        <td>{{ data.insertTime }}</td>
        <td>{{ data.updateTime }}</td>
      </tr>
    </tbody>
  </table>

  <br />
  <br />
  <!-- 페이지네이션 -->
  <div class="text-center d-flex justify-content-center">
    <b-pagination
      v-model="pageIndex"
      :total-rows="totalCount"
      :per-page="recordCountPerPage"
      @click="getNotice"
    ></b-pagination>
  </div>
</template>

<script>
import AnnouncementService from "@/services/basic/AnnouncementService";
export default {
  data() {
    return {
      pageIndex: 1, // 현재페이지번호
      totalCount: 0, // 전체개수
      recordCountPerPage: 3, // 화면에 보일 개수
      searchKeyword: "", // 검색어
      notices: [],
    };
  },
  computed: {
    pagedItems() {
      const start = (this.pageIndex - 1) * this.recordCountPerPage;
      const end = start + this.recordCountPerPage;
      return this.items.slice(start, end);
    },
  },
  methods: {
    calculateIndex(index) {
      return (this.pageIndex - 1) * this.recordCountPerPage + index + 1;
    },
    async getNotice() {
      try {
        let response = await AnnouncementService.getAll(
          this.searchKeyword,
          this.pageIndex - 1,
          this.recordCountPerPage
        );
        const { results, totalCount } = response.data;
        console.log(response.data); // 디버깅
        this.notices = results;
        this.totalCount = totalCount;
      } catch (error) {
        console.log(error);
      }
      console.log(`Fetching data for page ${this.pageIndex}`);
      // 필요한 경우, 서버에서 데이터를 다시 로드
    },
  },
  mounted() {
    this.getNotice();
  },
};
</script>
<style></style>
