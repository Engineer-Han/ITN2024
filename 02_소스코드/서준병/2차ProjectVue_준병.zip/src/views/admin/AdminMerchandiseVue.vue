<template>
  <div>
    <h3>전체 상품 관리</h3>
    <hr />
    <br />
    <br />

    <h3>상품 검색</h3>

    <table class="table table-bordered table-sm">
      <tbody>
        <tr>
          <th scope="row">검색어</th>
          <td>
            <div class="row align-items-center">
              <div class="col-auto">
                <select
                  class="form-select form-select"
                  style="width: 200px"
                  aria-label=".form-select example"
                >
                  <option selected>검색어 선택</option>
                  <option value="1">상품명</option>
                  <option value="2">상품코드</option>
                  <option value="3">모델명</option>
                </select>
              </div>
              <div class="col">
                <input
                  type="text"
                  class="form-control"
                  placeholder="검색어를 입력하세요"
                />
              </div>
            </div>
          </td>
        </tr>

        <tr>
          <th scope="row">카테고리</th>
          <td>
            <div class="row align-items-center">
              <div class="col-auto">
                <select
                  class="form-select form-select"
                  style="width: 200px"
                  aria-label=".form-select example"
                >
                  <option selected>검색어 선택</option>
                  <option value="1">두루마기, 도포</option>
                  <option value="2">저고리</option>
                  <option value="3">바지, 치마</option>
                </select>
              </div>
              <div class="col">
                <input
                  type="text"
                  class="form-control"
                  placeholder="검색어를 입력하세요"
                />
              </div>
            </div>
          </td>
        </tr>

        <tr>
          <th scope="row">상품재고</th>
          <td class>
            재고 수량 <input type="number" /> 개 이상 ~
            <input type="number" /> 개 이하
          </td>
        </tr>

        <tr>
          <th scope="row">상품가격</th>
          <td class>
            판매 가격 <input type="number" /> 원 이상 ~
            <input type="number" /> 원 이하
          </td>
        </tr>
      </tbody>
    </table>

    <div class="text-center">
      <button type="button" class="btn btn-primary btn-sm me-2">검색</button>
      <button type="button" class="btn btn-secondary btn-sm">초기화</button>
    </div>

    <br />
    <br />

    <div class="row">
      <div class="col">
        <p class="fs-3 text">상품 리스트</p>
      </div>
      <div class="col">
        <p class="d-grid gap-2 d-md-flex justify-content-md-end">
          <a href="/AdminMerchandiseAdd"
            ><button class="btn btn-primary me-md-2" type="button">
              상품 등록
            </button></a
          >
        </p>
      </div>
    </div>
    <hr />

    <table class="table">
      <thead>
        <tr class="table-secondary">
          <th scope="col">번호</th>
          <th scope="col">상품코드</th>
          <th scope="col">메인 이미지</th>
          <th scope="col">상품명</th>
          <th scope="col">카테고리</th>
          <th scope="col">제품 성별</th>
          <th scope="col">단일가격</th>
          <th scope="col">등록날짜</th>
          <th scope="col">수정날짜</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="(data, index) in product" :key="index">
          <td>{{ calculateIndex(index) }}</td>
          <td>
            <router-link :to="'/AdminMerchandise/' + data.prid">{{
              data.code
            }}</router-link>
          </td>
          <td><img :src="data.titleImageUrl" alt="이미지" /></td>
          <td>{{ data.name }}</td>
          <td>{{ data.karegorie }}</td>
          <td>{{ data.gender }}</td>
          <td>{{ data.price }}</td>
          <td>{{ data.insertTime }}</td>
          <td>{{ data.updateTime }}</td>
        </tr>
      </tbody>
    </table>

    <br />
    <br />

    <!-- 페이지네이션 -->
    <div class="text-center d-flex justify-content-center">
      <b-pagination
        v-model="pageIndex"
        :total-rows="totalCount"
        :per-page="recordCountPerPage"
        @click="getProduct"
      ></b-pagination>
    </div>

    <br />
    <br />
  </div>
</template>
<script>
import ProductService from "@/services/basic/ProductService";
export default {
  data() {
    return {
      pageIndex: 1, // 현재페이지번호
      totalCount: 0, // 전체개수
      recordCountPerPage: 5, // 화면에 보일 개수
      searchKeyword: "", // 검색어
      product: [],
    };
  },
  computed: {
    pagedItems() {
      const start = (this.pageIndex - 1) * this.recordCountPerPage;
      const end = start + this.recordCountPerPage;
      return this.items.slice(start, end);
    },
  },
  methods: {
    calculateIndex(index) {
      return (this.pageIndex - 1) * this.recordCountPerPage + index + 1;
    },
    async getProduct() {
      try {
        let response = await ProductService.getAllAdmin(
          this.searchKeyword,
          this.pageIndex - 1,
          this.recordCountPerPage
        );
        const { results, totalCount } = response.data;
        console.log(response.data); // 디버깅
        this.product = results;
        this.totalCount = totalCount;
      } catch (error) {
        console.log(error);
        console.log(`Fetching data for page ${this.pageIndex}`);
        // 필요한 경우, 서버에서 데이터를 다시 로드
      }
    },
  },

  mounted() {
    this.getProduct();
  },
};
</script>
<style></style>
