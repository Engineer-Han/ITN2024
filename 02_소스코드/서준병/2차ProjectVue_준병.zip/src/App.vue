<template>
  <div class="container-fluid mt-3">
    <div class="row">
      <!-- TODO: 머리말 : HeaderCom -->
      <SideMenue />
      <!-- TODO: 아래 태그(본문) -->
      <div class="col-md-10 mt-5 container">
        <router-view />
      </div>
    </div>
  </div>
</template>

<script>
import SideMenue from "./components/SideMenue.vue";
export default {
  components: {
    SideMenue,
  },
};
</script>

<style></style>
