import axios from "axios";
// 벡엔드 주소 : springboot 주소(컨트롤러주소)
const baseURL = "http://localhost:8000/api/basic";

const insertForm = (data) => {
  console.log(data);
  // FormData 객체 생성
  let formData = new FormData();

  // ProductDto 데이터 추가 (예: 이름, 카테고리 등)
  formData.append("name", data.name);
  formData.append("karegorie", data.karegorie);
  formData.append("gender", data.gender);
  formData.append("price", data.price);
  formData.append("contents", data.contents);

  // 파일 데이터 추가 (각 파일에 맞는 키 이름 사용)
  formData.append("mainImg", data.fileTitle); // 메인 이미지
  formData.append("detailImg1", data.fileDetailImg1); // 세부 이미지 1
  formData.append("detailImg2", data.fileDetailImg2); // 세부 이미지 2
  formData.append("detailImg3", data.fileDetailImg3); // 세부 이미지 3
  formData.append("detailImg4", data.fileDetailImg4); // 세부 이미지 4
  formData.append("detailImg5", data.fileDetailImg5); // 세부 이미지 5
  formData.append("detailImg6", data.fileDetailImg6); // 세부 이미지 6
  formData.append("detailImg7", data.fileDetailImg7); // 세부 이미지 7
  formData.append("detailImg8", data.fileDetailImg8); // 세부 이미지 8
  formData.append("detailImg9", data.fileDetailImg9); // 세부 이미지 9
  formData.append("detailImg10", data.fileDetailImg10); // 세부 이미지 10
  formData.append("detailImg11", data.fileDetailImg11); // 세부 이미지 11

  return formData;
};

const getAll = (searchKeyword, pageIndex, recordCountPerPage) => {
  return axios.get(
    baseURL +
      `/product?searchKeyword=${searchKeyword}&pageIndex=${pageIndex}&recordCountPerPage=${recordCountPerPage}`
  );
};
const getAllAdmin = (searchKeyword, pageIndex, recordCountPerPage) => {
  return axios.get(
    baseURL +
      `/product/admin?searchKeyword=${searchKeyword}&pageIndex=${pageIndex}&recordCountPerPage=${recordCountPerPage}`
  );
};
const get = (prid) => {
  return axios.get(baseURL + `/product/${prid}`);
};
const getAdmin = (prid) => {
  return axios.get(baseURL + `/product/admin/${prid}`);
};
const getCategory = (siteName) => {
  return axios.get(baseURL + `/product/${siteName}`);
};
const insert = (data) => {
  // insertForm 함수를 호출하여 FormData 객체 생성
  let form = insertForm(data);

  // axios를 사용해 서버로 POST 요청 보내기
  return axios.post(baseURL + "/product/insert", form, {
    headers: {
      "Content-Type": "multipart/form-data"
    },
  });
};

const update = (uuid, data) => {
  // insertForm 함수를 호출하여 FormData 객체 생성
  let form = insertForm(data);

  // axios를 사용해 서버로 PUT 요청 보내기
  return axios.put(baseURL + `/product/update/${uuid}`, form, {
    headers: {
      "Content-Type": "multipart/form-data",
    },
  });
};
const remove = (prid) => {
  return axios.delete(baseURL + `/product/delete/${prid}`);
};
const ProductService = {
  getAll,
  getAllAdmin,
  get,
  getAdmin,
  getCategory,
  insert,
  update,
  remove,
};

export default ProductService;
