<template>
  <h3>상품 관리</h3>
  <hr />

  <br />
  <br />

  <h3>상품 등록</h3>
  <hr />

  <div class="mb-3">
    <label class="form-label"> 상품명</label>
    <input
      type="text"
      class="form-control"
      placeholder="상품명을 적어주세요"
      v-model="products.name"
    />
  </div>

  <br />

  <div class="mb-3">
    <label for="exampleFormControlTextarea1" class="form-label">카테고리</label>
    <select
      class="form-select"
      aria-label="Default select example"
      v-model="products.karegorie"
    >
      <option selected>제품 카테고리를 선택하세요</option>
      <option value="두루마기">두루마기</option>
      <option value="저고리">저고리</option>
      <option value="바지">바지</option>
      <option value="치마">치마</option>
    </select>
  </div>

  <br />

  <div class="mb-3">
    <label for="exampleFormControlTextarea1" class="form-label"
      >성별(Sex)</label
    >
    <select
      class="form-select"
      aria-label="Default select example"
      v-model="products.gender"
    >
      <option selected>제품 성별 카테고리를 선택하세요</option>
      <option value="남성">남성</option>
      <option value="여성">여성</option>
      <option value="남녀공용">남녀공용</option>
    </select>
  </div>

  <br />

  <div class="mb-3">
    <label for="exampleFormControlTextarea1" class="form-label"
      >단일 가격 지정</label
    >
    <input
      class="form-control"
      type="number"
      placeholder="가격 지정을 해주세요"
      aria-label="default input example"
      v-model="products.price"
    />
  </div>

  <div class="mb-3">
    <label for="exampleFormControlTextarea1" class="form-label">상세내용</label>
    <textarea
      class="form-control"
      id="exampleFormControlTextarea1"
      rows="3"
      v-model="products.contents"
    ></textarea>
  </div>

  <br />
  <!-- 사진 파일 입력 -->
  <h3>메인 사진 (페이지 상단)</h3>
  <hr />
  <label for="exampleFormControlTextarea1" class="form-label">메인 사진</label>
  <div class="input-group">
    <input
      type="file"
      class="form-control"
      aria-describedby="inputGroupFileAddon04"
      aria-label="Upload"
      ref="titleImageUrl"
      @change="select('titleImageUrl')"
    />
    <button
      class="btn btn-outline-secondary"
      type="button"
      id="inputGroupFileAddon04"
    >
      파일 불러오기
    </button>
  </div>
  <br />

  <label for="exampleFormControlTextarea1" class="form-label"
    >메인 서브 사진 2개</label
  >
  <div class="input-group">
    <input
      type="file"
      class="form-control"
      aria-describedby="inputGroupFileAddon04"
      aria-label="Upload"
      ref="detailImageUrl1"
      @change="select('detailImageUrl1')"
    />
    <button
      class="btn btn-outline-secondary"
      type="button"
      id="inputGroupFileAddon04"
    >
      파일 불러오기
    </button>
  </div>
  <br />
  <div class="input-group">
    <input
      type="file"
      class="form-control"
      aria-describedby="inputGroupFileAddon04"
      aria-label="Upload"
      ref="detailImageUrl2"
      @change="select('detailImageUrl2')"
    />
    <button
      class="btn btn-outline-secondary"
      type="button"
      id="inputGroupFileAddon04"
    >
      파일 불러오기
    </button>
  </div>

  <br />
  <br />

  <h3>상세 사진 (이미지 하단)</h3>
  <hr />
  <label for="exampleFormControlTextarea1" class="form-label"
    >상세사진 9개</label
  >
  <div class="input-group">
    <input
      type="file"
      class="form-control"
      aria-describedby="inputGroupFileAddon04"
      aria-label="Upload"
      ref="detailImageUrl3"
      @change="select('detailImageUrl3')"
    />
    <button
      class="btn btn-outline-secondary"
      type="button"
      id="inputGroupFileAddon04"
    >
      파일 불러오기
    </button>
  </div>
  <br />

  <div class="input-group">
    <input
      type="file"
      class="form-control"
      aria-describedby="inputGroupFileAddon04"
      aria-label="Upload"
      ref="detailImageUrl4"
      @change="select('detailImageUrl4')"
    />
    <button
      class="btn btn-outline-secondary"
      type="button"
      id="inputGroupFileAddon04"
    >
      파일 불러오기
    </button>
  </div>
  <br />

  <div class="input-group">
    <input
      type="file"
      class="form-control"
      aria-describedby="inputGroupFileAddon04"
      aria-label="Upload"
      ref="detailImageUrl5"
      @change="select('detailImageUrl5')"
    />
    <button
      class="btn btn-outline-secondary"
      type="button"
      id="inputGroupFileAddon04"
    >
      파일 불러오기
    </button>
  </div>
  <br />

  <div class="input-group">
    <input
      type="file"
      class="form-control"
      aria-describedby="inputGroupFileAddon04"
      aria-label="Upload"
      ref="detailImageUrl6"
      @change="select('detailImageUrl6')"
    />
    <button
      class="btn btn-outline-secondary"
      type="button"
      id="inputGroupFileAddon04"
    >
      파일 불러오기
    </button>
  </div>
  <br />

  <div class="input-group">
    <input
      type="file"
      class="form-control"
      aria-describedby="inputGroupFileAddon04"
      aria-label="Upload"
      ref="detailImageUrl7"
      @change="select('detailImageUrl7')"
    />
    <button
      class="btn btn-outline-secondary"
      type="button"
      id="inputGroupFileAddon04"
    >
      파일 불러오기
    </button>
  </div>
  <br />

  <div class="input-group">
    <input
      type="file"
      class="form-control"
      aria-describedby="inputGroupFileAddon04"
      aria-label="Upload"
      ref="detailImageUrl8"
      @change="select('detailImageUrl8')"
    />
    <button
      class="btn btn-outline-secondary"
      type="button"
      id="inputGroupFileAddon04"
    >
      파일 불러오기
    </button>
  </div>
  <br />

  <div class="input-group">
    <input
      type="file"
      class="form-control"
      aria-describedby="inputGroupFileAddon04"
      aria-label="Upload"
      ref="detailImageUrl9"
      @change="select('detailImageUrl9')"
    />
    <button
      class="btn btn-outline-secondary"
      type="button"
      id="inputGroupFileAddon04"
    >
      파일 불러오기
    </button>
  </div>
  <br />

  <div class="input-group">
    <input
      type="file"
      class="form-control"
      aria-describedby="inputGroupFileAddon04"
      aria-label="Upload"
      ref="detailImageUrl10"
      @change="select('detailImageUrl10')"
    />
    <button
      class="btn btn-outline-secondary"
      type="button"
      id="inputGroupFileAddon04"
    >
      파일 불러오기
    </button>
  </div>
  <br />

  <div class="input-group">
    <input
      type="file"
      class="form-control"
      aria-describedby="inputGroupFileAddon04"
      aria-label="Upload"
      ref="detailImageUrl11"
      @change="select('detailImageUrl11')"
    />
    <button
      class="btn btn-outline-secondary"
      type="button"
      id="inputGroupFileAddon04"
    >
      파일 불러오기
    </button>
  </div>
  <br />

  <br />
  <br />

  <div class="text-center">
    <button type="button" class="btn btn-primary me-2" @click="save">
      등록
    </button>
    <a href="/AdminMerchandise"
      ><button type="button" class="btn btn-danger">취소</button></a
    >
  </div>
  <br />
  <br />
  <br />
</template>
<script>
import ProductService from "@/services/basic/ProductService";
export default {
  data() {
    return {
      products: {
        prid: "",
        code: "",
        name: "",
        karegorie: "",
        gender: "",
        price: "",
        contents: "",
        titleImageUrl: "",
        detailImageUrl1: "",
        detailImageUrl2: "",
        detailImageUrl3: "",
        detailImageUrl4: "",
        detailImageUrl5: "",
        detailImageUrl6: "",
        detailImageUrl7: "",
        detailImageUrl8: "",
        detailImageUrl9: "",
        detailImageUrl10: "",
        detailImageUrl11: "",
        insertTime: "",
        updateTime: "",
      },
    };
  },

  methods: {
    select(refName) {
      this.products[refName] = this.$refs[refName].files[0];
    },

    async save() {
      try {
        let response = await ProductService.insert(this.products);
        console.log(response.data);
        this.$router.push("/AdminMerchandise");
      } catch (error) {
        console.log(error);
      }
    },
  },
};
</script>
<style></style>
