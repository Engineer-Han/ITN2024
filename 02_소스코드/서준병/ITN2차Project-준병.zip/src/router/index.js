import { createRouter, createWebHistory } from "vue-router";

const routes = [
  {
    path: "/AdminHome",
    component: () => import("../views/admin/AdminHomeVue.vue"),
  },
  {
    path: "/AdminMember",
    component: () => import("../views/admin/AdminMemberVue.vue"),
  },
  {
    path: "/AdminMerchandise",
    component: () => import("../views/admin/AdminMerchandiseVue.vue"),
  },
  {
    path: "/AdminMerchandiseAdd",
    component: () => import("../views/admin/AdminMerchandiseAdd.vue"),
  },
  {
    path: "/AdminMerchandiseUpdate",
    component: () => import("../views/admin/AdminMerchandiseUpdate.vue"),
  },
  {
    path: "/AdminOrder",
    component: () => import("../views/admin/AdminOrderVue.vue"),
  },
  {
    path: "/AdminOrderDetail",
    component: () => import("../views/admin/AdminOrderDetailVue.vue"),
  },
  {
    path: "/AdminAnouncement",
    component: () => import("../views/admin/AdminAnnouncementVue.vue"),
  },
  {
    path: "/AdminAnouncementAdd",
    component: () => import("../views/admin/AdminAnnouncementAdd.vue"),
  },
  {
    path: "/AdminAnouncementDetailView",
    component: () => import("../views/admin/AdminAnnouncementDetailView.vue"),
  },
  {
    path: "/AdminFaq",
    component: () => import("../views/admin/AdminFaqVue.vue"),
  },
  {
    path: "/AdminFaqDetailView",
    component: () => import("../views/admin/AdminFaqDetailView.vue"),
  },
];

const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes,
});

export default router;
