<template>
  <h3>1:1 문의</h3>
  <hr />

  <br />
  <br />

  <h3>1:1 문의 상세 조회</h3>
  <hr />

  <!-- TODO : div에 v-model 써서 작성자, 등록날짜 넣기 -->
  <div class="container text-center">
    <div class="row">
      <div class="col">작성자</div>
      <div class="col">등록 날짜</div>
      <div class="col">고유ID</div>
    </div>
  </div>

  <hr />

  <div class="mb-3">
    <!-- TODO : div에 v-model 써서 제목 넣기 -->
    <div class="fs-3 text-center">예시 제목입니다!</div>
  </div>
  <hr />

  <div class="mb-3">
    <!-- TODO : div에 v-model 써서 내용 넣기 -->
    <div class="fs-4">
      예시 내용 입니다 Lorem ipsum dolor sit, amet consectetur adipisicing elit.
      Possimus, corporis placeat harum voluptatem qui officiis. Qui modi odit
      aut excepturi hic placeat odio. Ducimus est officia repellat, eius minima
      ullam?
    </div>
  </div>
  <hr />

  <br />

  <!-- 답변 입력칸 -->
  <div v-if="showReplyInput" class="mt-3">
    <textarea
      class="form-control mb-2"
      rows="3"
      placeholder="답변 내용을 입력하세요"
      v-model="newReply"
    ></textarea>
    <button type="button" class="btn btn-primary me-2" @click="addReply">
      등록
    </button>
    <a href="/AdminFaqDetailView"
      ><button type="button" class="btn btn-secondary">취소</button></a
    >
  </div>

  <!-- 등록된 답변 목록 -->
  <div v-if="replies.length > 0" class="mt-4">
    <h4>답변 내용</h4>
    <ul class="list-group">
      <li
        v-for="(reply, index) in replies"
        :key="index"
        class="list-group-item"
      >
        {{ reply }}
        <p class="text-end">
          <button type="button" class="btn btn-primary me-2">답변 수정</button>
          <a href="#"
            ><button type="button" class="btn btn-danger">답변 삭제</button></a
          >
        </p>
      </li>
    </ul>
  </div>

  
  <br />

  <div v-if="!showReplyInput" class="text-center">
    <button
      type="button"
      class="btn btn-primary me-2"
      @click="toggleReplyInput"
    >
      답변하기
    </button>
    <button type="button" class="btn btn-danger me-2">문의 삭제</button>
    <a href="/AdminFaq"
      ><button type="button" class="btn btn-secondary">확인/뒤로가기</button></a
    >
  </div>

  <br />
  <br />
</template>
<script>
export default {
  data() {
    return {
      showReplyInput: false, // 답변 입력칸 표시 여부
      newReply: "", // 새로운 답변 내용
      replies: [], // 등록된 답변 목록
    };
  },
  methods: {
    toggleReplyInput() {
      this.showReplyInput = !this.showReplyInput; // 답변 입력칸 표시/숨기기
    },
    addReply() {
      if (this.newReply.trim()) {
        this.replies.push(this.newReply); // 답변 목록에 추가
        this.newReply = ""; // 입력칸 초기화
        this.showReplyInput = false; // 입력칸 숨기기
      } else {
        alert("답변 내용을 입력해주세요!");
      }
    },
  },
};
</script>
<style></style>
