<template>
  <div>
    <h3>주문 상세 정보 관리</h3>
    <hr />

    <br />
    <br />

    <h3>주문 상세 조회 리스트</h3>
    <br />

    <div class="fw-bold fs-4 text-danger">주문 번호 : [주문번호]</div>

    <br />

    <table class="table">
      <thead>
        <tr class="table-secondary">
          <th scope="col">제품 메인 이미지(Img)</th>
          <th scope="col">주문번호</th>
          <th scope="col">제품명</th>
          <th scope="col">사이즈</th>
          <th scope="col">가격</th>
          <th scope="col">개수</th>
          <th scope="col">등록날짜(주문날짜)</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>[제품(Img)]</td>
          <td>[주문번호]</td>
          <td>[제품명]</td>
          <td>[사이즈]</td>
          <td>[가격]</td>
          <td>[개수]</td>
          <td>[등록날짜(주문날짜)]</td>
        </tr>
      </tbody>
    </table>

    <br />
    <br />

    <h3>주문자 결제 내역</h3>
    <hr />

    <table class="table">
      <thead>
        <tr class="table-secondary">
          <th scope="col">결제 번호</th>
          <th scope="col">결제 코드</th>
          <th scope="col">Email(ID)</th>
          <th scope="col">결제 방식</th>
          <th scope="col">결제 금액</th>
          <th scope="col">배송ID</th>
          <th scope="col">결제날짜</th>
          <th scope="col">취소날짜</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>[결제 번호]</td>
          <td>[결제 코드]]</td>
          <td>[Email(ID)]</td>
          <td>[결제 방식]</td>
          <td>[결제 금액]</td>
          <td>[배송ID]</td>
          <td>[결제날짜]</td>
          <td>[취소날짜]</td>
        </tr>
      </tbody>
    </table>

    <br />
    <br />

    <h3>주문자 정보</h3>
    <hr />

    <table class="table">
      <thead>
        <tr class="table-secondary">
          <th scope="col">Email(ID)</th>
          <th scope="col">주문자 주소</th>
          <th scope="col">주문자 우편번호</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>[Email(ID)]</td>
          <td>[주문자 주소]</td>
          <td>[주문자 우편번호]</td>
        </tr>
      </tbody>
    </table>

    <br />
    <br />

    <h3>수취인/배송 정보</h3>
    <hr />

    <table class="table">
      <thead>
        <tr class="table-secondary">
          <th scope="col">배송ID</th>
          <th scope="col">택배사</th>
          <th scope="col">배송상태</th>
          <th scope="col">Email(ID)</th>
          <th scope="col">수취인 이름</th>
          <th scope="col">수취인 전화번호</th>
          <th scope="col">수취인 우편번호</th>
          <th scope="col">수취인 주소</th>
          <th scope="col">등록 날짜</th>
          <th scope="col">취소 날짜</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>[배송ID]</td>
          <td>[택배사]]</td>
          <td>[배송상태]</td>
          <td>[Email(ID)]</td>
          <td>[수취인 이름]</td>
          <td>[수취인 전화번호]</td>
          <td>[수취인 우편번호]</td>
          <td>[수취인 주소]</td>
          <td>[등록 날짜]</td>
          <td>[취소 날짜]</td>
        </tr>
      </tbody>
    </table>

    <br />
    <br />

    <div class="text-center">
      <a href="/AdminOrder"
        ><button type="button" class="btn btn-secondary">
          확인/뒤로가기
        </button></a
      >
    </div>

    <br />
    <br />
  </div>
</template>
<script>
export default {};
</script>
<style></style>
