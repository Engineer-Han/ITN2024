// services/basic/FaqService.js
import axios from "axios";
const baseURL = "http://localhost:8000/api";
// 전체조회
const getAll = (searchKeyword, pageIndex, recordCountPerPage) => {
  return axios.get(
    baseURL +
      `/basic/faq?searchKeyword=${searchKeyword}&pageIndex=${pageIndex}&recordCountPerPage=${recordCountPerPage}`
  );
};

// faq 생성 /api/basic/faq
const insert = (data) => {
  return axios.post(baseURL + `/basic/faq`, data);
};

// 상세조회 /api/basic/faq/{fno}
const get = (fno) => {
  return axios.get(baseURL + `/basic/faq/${fno}`);
};

// 수정 /api/basic/faq/{fno}
const update = (fno, data) => {
  return axios.put(baseURL + `/basic/faq/${fno}`, data);
};

// 삭제 /api/basic/faq/{fno}
const remove = (fno, data) => {
  return axios.delete(baseURL + `/basic/faq/${fno}`, data);
};

// 객체 : getAll 넣어 export
const FaqService = {
  getAll,
  insert,
  get,
  update,
  remove,
};
export default FaqService;
