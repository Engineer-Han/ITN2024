// // services/auth/MemberService.js
// import axios from "axios";
//
// const baseURL = "http://localhost:8000/api"
//
// // 전체조회
// const getAll = (searchKeyword, pageIndex, recordCountPerPage) => {
//     return axios
//         .get(baseURL + `/auth/member?searchKeyword=${searchKeyword}&pageIndex=${pageIndex}&recordCountPerPage=${recordCountPerPage}`);
// };
// const get = (email) => {
//     return axios.get(baseURL + `/auth/member/${email}`);
// }
//
// const MemberService = {
//     getAll, get
// }
// export default MemberService;

import axios from "axios";

const baseURL = "http://localhost:8000/api"

// 전체조회
const getAll = (searchCriteria, searchKeyword, pageIndex, recordCountPerPage) => {
    return axios
        .get(baseURL + `/auth/member`, {
            params: {
                searchCriteria,  // 검색 기준 (예: 'email', 'name', 'phoneNumber')
                searchKeyword,   // 검색어
                pageIndex,       // 페이지 인덱스
                recordCountPerPage // 페이지당 레코드 수
            }
        });
};

const get = (email) => {
    return axios.get(baseURL + `/auth/member/${email}`);
}

const MemberService = {
    getAll,
    get
}

export default MemberService;
