<template>
  <div>
    <h3>전체 상품 관리</h3>
    <hr />
    <br />
    <br />

    <h3>상품 검색</h3>

    <table class="table table-bordered table-sm">
      <tbody>
        <tr>
          <th scope="row">검색어</th>
          <td>
            <div class="row align-items-center">
              <div class="col-auto">
                <select
                  class="form-select form-select"
                  style="width: 200px"
                  aria-label=".form-select example"
                >
                  <option selected>검색어 선택</option>
                  <option value="1">상품명</option>
                  <option value="2">상품코드</option>
                  <option value="3">모델명</option>
                </select>
              </div>
              <div class="col">
                <input
                  type="text"
                  class="form-control"
                  placeholder="검색어를 입력하세요"
                />
              </div>
            </div>
          </td>
        </tr>

        <tr>
          <th scope="row">카테고리</th>
          <td>
            <div class="row align-items-center">
              <div class="col-auto">
                <select
                  class="form-select form-select"
                  style="width: 200px"
                  aria-label=".form-select example"
                >
                  <option selected>검색어 선택</option>
                  <option value="1">두루마기, 도포</option>
                  <option value="2">저고리</option>
                  <option value="3">바지, 치마</option>
                </select>
              </div>
              <div class="col">
                <input
                  type="text"
                  class="form-control"
                  placeholder="검색어를 입력하세요"
                />
              </div>
            </div>
          </td>
        </tr>

        <tr>
          <th scope="row">상품재고</th>
          <td class>
            재고 수량 <input type="number" /> 개 이상 ~
            <input type="number" /> 개 이하
          </td>
        </tr>

        <tr>
          <th scope="row">상품가격</th>
          <td class>
            판매 가격 <input type="number" /> 원 이상 ~
            <input type="number" /> 원 이하
          </td>
        </tr>
      </tbody>
    </table>

    <div class="text-center">
      <button type="button" class="btn btn-primary btn-sm me-2">검색</button>
      <button type="button" class="btn btn-secondary btn-sm">초기화</button>
    </div>

    <br />
    <br />

    <div class="row">
      <div class="col">
        <p class="fs-3 text">상품 리스트</p>
      </div>
      <div class="col">
        <p class="d-grid gap-2 d-md-flex justify-content-md-end">
          <a href="/AdminMerchandiseAdd"
            ><button class="btn btn-primary me-md-2" type="button">
              상품 등록
            </button></a
          >
        </p>
      </div>
    </div>
    <hr />

    <table class="table">
      <thead>
        <tr class="table-secondary">
          <th scope="col">번호</th>
          <th scope="col">메인 이미지</th>
          <th scope="col">상품코드</th>
          <th scope="col">상품명</th>
          <th scope="col">카테고리</th>
          <th scope="col">제품 성별</th>
          <th scope="col">단일가격</th>
          <th scope="col">등록날짜</th>
          <th scope="col">상세날짜</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td><a href="/AdminMerchandiseUpdate">[번호]</a></td>
          <td>[메인 이미지]</td>
          <td>[상품코드]</td>
          <td>[상품명]</td>
          <td>[카테고리]</td>
          <td>[제품 성별]</td>
          <td>[단일가격]</td>
          <td>[등록날짜]</td>
          <td>[상세날짜]</td>
        </tr>
      </tbody>
    </table>

    <br />
    <br />

    <div>
      <nav aria-label="Page navigation example">
        <ul class="pagination justify-content-center">
          <li class="page-item">
            <a class="page-link" href="#" aria-label="Previous">
              <span aria-hidden="true">&laquo;</span>
            </a>
          </li>
          <li class="page-item"><a class="page-link" href="#">1</a></li>
          <li class="page-item"><a class="page-link" href="#">2</a></li>
          <li class="page-item"><a class="page-link" href="#">3</a></li>
          <li class="page-item">
            <a class="page-link" href="#" aria-label="Next">
              <span aria-hidden="true">&raquo;</span>
            </a>
          </li>
        </ul>
      </nav>
    </div>

    <br />
    <br />
  </div>
</template>
<script>
export default {};
</script>
<style></style>
