package com.simplecoding.simpledms.vo.basic;

import lombok.*;

/**
 * @author : KTE
 * @fileName : Dept
 * @since : 24. 10. 23.
 * description : 부서 vo
 *  TODO: DB 테이블 : 컬럼(속성), 테이블명(클래스명)
 *    DB   : 언더바 표기법 (단어_단어)
 *    Java : 낙타표기법(소문자대문자)
 */

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@ToString
//ENO, ENAME, JOB, MANAGER, HIREDATE, SALARY, COMMISSION, DNO
public class Emp {
    private Integer eno;
    private String ename;
    private String job;
    private String hiredate;
    private Integer manager;
    private Integer salary;
    private Integer commission;
    private Integer dno;
}
