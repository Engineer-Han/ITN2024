// services/advanced/GalleryService.js
import axios from "axios";
const baseURL = "http://localhost:8000/api";

// 전체조회
const getAll = (searchKeyword, pageIndex, recordCountPerPage) => {
  return axios.get(
    baseURL +
      `/advanced/gallery?searchKeyword=${searchKeyword}&pageIndex=${pageIndex}&recordCountPerPage=${recordCountPerPage}`
  );
};
const insertForm = (data)=>{
  let formData = new FormData();
  formData.append("galleryTitle", data.galleryTitle);
  formData.append("image", data.image);
  return formData;
}
// insert 함수
const insert = (data) => {
  let form = insertForm(data);
  return axios.post(baseURL+"/advanced/gallery/add", form,
    {
      headers: {"Content-Type": "multipart/form-data",}
    }
  );
}
// 상세조회
const get = (uuid)=>{
  return axios.get(baseURL+`/advanced/gallery/get/${uuid}`);
}
// 수정 
const update = (uuid, data)=>{
  let form = insertForm(data);
  return axios.put(baseURL+`/advanced/gallery/update/${uuid}`, form,
    {
      headers: {"Content-Type": "multipart/form-data",}
    }
  );  
}
const GalleryService = {
  getAll,
  insert,
  get,
  update
};
export default GalleryService;
