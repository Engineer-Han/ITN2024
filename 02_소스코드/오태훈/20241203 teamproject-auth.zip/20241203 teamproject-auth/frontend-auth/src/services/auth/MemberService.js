// services/auth/MemberService.js
import axios from "axios";
const baseURL = "http://localhost:8000/api"

// 회원가입(insert)
const insert = (data) => {
    return axios.post(baseURL+"/auth/register", data);
}
// 로그인 : post 방식(보안)
const login = (data) => {
    return axios.post(baseURL+"/auth/login", data);
}
// 로그아웃 :
const logout = ()=>{
    // TODO: 사용법(삭제) : localStorage.removeItem("키");
    localStorage.removeItem("user");
}

const MemberService = {
    insert,
    login,
    logout
}
export default MemberService;