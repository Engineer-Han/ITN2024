// services - EmpService.js
import axios from "axios";
const baseURL = "http://localhost:8000/api"

// 전체조회
const getAll = (searchKeyword, pageIndex, recordCountPerPage) => {
    return axios
       .get(baseURL+`/basic/emp?searchKeyword=${searchKeyword}&pageIndex=${pageIndex}&recordCountPerPage=${recordCountPerPage}`);
};
// TODO: 사원생성 : url(/basic/emp)
const insert = (data) => {
    return axios.post(baseURL+"/basic/emp", data);
}
// TODO: 상세조회 : url(/basic/emp/{eno})
const get = (eno) => {
    return axios.get(baseURL+`/basic/emp/${eno}`);
}
// TODO: 수정(dno, data) : 벡엔드 수정 url : /basic/emp/{eno}
const update = (eno, data)=>{
    return axios.put(baseURL+`/basic/emp/${eno}`,data);
}
// TODO: 삭제(eno) : 벡엔드 삭제 url: /basic/emp/deletion/{eno}
const remove = (eno)=>{
    return axios.delete(baseURL+`/basic/emp/deletion/${eno}`);
}
// 객체 : getAll 넣어 export
const EmpService = {
    getAll,
    insert,
    get,
    update,
    remove
}
export default EmpService;