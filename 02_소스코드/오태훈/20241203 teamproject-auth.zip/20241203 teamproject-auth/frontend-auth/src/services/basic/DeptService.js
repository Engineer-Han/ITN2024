// services - DeptService.js
import axios from "axios";
// 벡엔드 주소 : springboot 주소(컨트롤러주소)
const baseURL = "http://localhost:8000/api"

// TODO: 전체조회 : pageIndex(현재페이지번호), recordCountPerPage(화면에보일개수)
// TODO:           벡엔드로 요청 -> 벡엔드 sql 실행
// TODO: 사용법) axios.get(url);
const getAll = (searchKeyword, pageIndex, recordCountPerPage) => {
    return axios
       .get(baseURL+`/basic/dept?searchKeyword=${searchKeyword}&pageIndex=${pageIndex}&recordCountPerPage=${recordCountPerPage}`);
};
// TODO: 부서생성 : url(/basic/dept)
//                 json data(db에 생성될 객체)
const insert = (data) => {
    return axios.post(baseURL+"/basic/dept", data);
}
// TODO: 상세조회(dno): /basic/dept/{dno}
const get = (dno) => {
    return axios.get(baseURL+`/basic/dept/${dno}`);
}
// TODO: 수정(dno, data) : 벡엔드 수정 url : /basic/dept/{dno}
const update = (dno, data)=>{
    return axios.put(baseURL+`/basic/dept/${dno}`,data);
}
// TODO: 삭제(dno) : 벡엔드 삭제 url:
//            /basic/dept/deletion/{dno}
const remove = (dno)=>{
    return axios.delete(baseURL+`/basic/dept/deletion/${dno}`);
}
// 객체 : getAll 넣어 export
const DeptService = {
    getAll,
    insert,
    get,
    update,
    remove
}
export default DeptService;