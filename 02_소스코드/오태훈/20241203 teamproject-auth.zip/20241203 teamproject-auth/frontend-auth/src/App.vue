<template>
  <!-- 머리말 : HeaderCom -->
  <HeaderCom />
  <!-- 본문 -->
  <div class="container mt-3">
    <router-view />
  </div>
  <!-- 푸터 : FooterCom -->
  <FooterCom />
</template>

<script>
import HeaderCom from "./components/HeaderCom.vue";
import FooterCom from "./components/FooterCom.vue";

export default {
  components: {
    HeaderCom,
    FooterCom,
  },
};
</script>

<style scoped>
@import "@/assets/css/main.css";

</style>
