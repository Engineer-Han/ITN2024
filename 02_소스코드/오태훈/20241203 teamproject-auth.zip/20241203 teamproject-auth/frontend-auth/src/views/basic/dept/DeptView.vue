// views-basic-dept/DeptView.vue // vueInit
<template>
  <div>
    <!-- TODO: 검색어 입력상자 -->
    <div class="input-group mb-3">
      <input
        type="text"
        class="form-control"
        placeholder="검색어"
        v-model="searchKeyword"
      />
      <button class="btn btn-outline-secondary" type="button" @click="getDept">
        검색
      </button>
    </div>
    <!-- TODO: 부트스트랩 테이블 -->
    <table class="table">
      <thead>
        <tr>
          <th scope="col">dno</th>
          <th scope="col">dname</th>
          <th scope="col">loc</th>
          <th scope="col">action</th>
        </tr>
      </thead>
      <tbody>
        <!-- TODO: 반복문 : depts -->
        <tr v-for="(data, index) in depts" :key="index">
          <td>{{ data.dno }}</td>
          <td>{{ data.dname }}</td>
          <td>{{ data.loc }}</td>
          <td>
            <!-- a태그, router-link태그 -->
            <router-link :to='"/dept/" + data.dno'>
              <span class="badge text-bg-success">수정</span>
            </router-link>
          </td>
        </tr>
      </tbody>
    </table>
    <!-- TODO: 페이지 번호 : 부트스트랩뷰(페이지)  -->
    <div>
      <!-- TODO: v-model="뷰변수(현재페이지번호)"
                 ,total-rows="전체개수"
                 ,per-page="1페이지당화면에보일개수"
                    -->
      <b-pagination
        v-model="pageIndex"
        :total-rows="totalCount"
        :per-page="recodeCountPerPage"
        @click="getDept"
      ></b-pagination>
    </div>
  </div>
</template>
<script>
// 프론트 코딩 : 벡엔드(변수들 보내고) -> 벡엔드(sql 결과 리턴)
//              -> 프론트(json 반복문으로 화면출력)
// @ == src 폴더위치(절대경로)
import DeptService from "@/services/basic/DeptService";
export default {
  data() {
    return {
      pageIndex: 1, // 현재페이지번호
      totalCount: 0, // 전체개수
      recodeCountPerPage: 3, // 화면에보일개수
      searchKeyword: "", // 검색어
      depts: [], // 빈배열(json)
    };
  },
  methods: {
    // 함수 작성 : (비동기 코딩: async/await)
    // (복습) : 뷰함수 앞에 : async, axios 함수 앞에 : await
    async getDept() {
      try {
        let response = await DeptService.getAll(
          this.searchKeyword,
          this.pageIndex - 1,
          this.recodeCountPerPage
        );
        // TODO: 벡엔드 전송되는것: results(배열), totalCount(총개수)
        const { results, totalCount } = response.data;
        console.log(response.data); // 디버깅
        this.depts = results;
        this.totalCount = totalCount;
      } catch (error) {
        console.log(error);
      }
    },
  },
  // 화면이 뜰때 실행하는 함수
  mounted() {
    this.getDept();
  },
};
</script>
<style></style>
