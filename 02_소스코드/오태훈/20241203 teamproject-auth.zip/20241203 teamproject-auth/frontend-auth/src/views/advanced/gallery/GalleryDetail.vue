// GalleryDetail.vue // vueInit 
// 연습) update, select 완성
// 연습2) remove 완성
<template>
  <div>
    <!-- galleryTitle -->
    <div class="form-floating mb-3">
      <input
        type="text"
        class="form-control"
        id="galleryTitle"
        placeholder="galleryTitle"
        v-model="gallery.galleryTitle"
      />
      <label for="galleryTitle">galleryTitle</label>
    </div>

    <!-- TODO: 현재 이미지 보기 -->
    <div class="mb-3 col-12">
      <img :src="gallery.galleryFileUrl" width="200px" alt="이미지" />
    </div>

    <!-- 파일선택상자 -->
    <div class="input-group">
      <input type="file" class="form-control" ref="file" @change="select" />
      <button class="btn btn-warning" type="button" @click="update">
        수정
      </button>
    </div>
    <div class="mt-3">
      <button class="btn btn-danger" type="button" @click="remove">삭제</button>
    </div>
  </div>
</template>

<script>
import GalleryService from "@/services/advanced/GalleryService";
export default {
  data() {
    return {
      gallery: {
        uuid: this.$route.params.uuid, // 기본키
        galleryTitle: "",
        galleryFileUrl: "", // 다운로드 url
        image: undefined, // 선택이미지
      },
    };
  },
  methods: {
    async getDetail(uuid) {
      try {
        let response = await GalleryService.get(uuid);
        console.log(response.data); // 디버깅
        this.gallery = response.data;
      } catch (error) {
        console.log(error);
      }
    },
    select() {
      this.gallery.image = this.$refs.file.files[0];
    },
    async update() {
      try {
        // TODO: fileDB -> fileDb 고칠것
        let response = await GalleryService.update(
          this.gallery.uuid,
          this.gallery
        );
        console.log(response.data); // 디버깅
        alert("수정되었습니다.");
      } catch (error) {
        this.gallery.image = undefined;
        console.log(error);
      }
    },
    remove() {},
  },
  mounted() {
    this.getDetail(this.$route.params.uuid);
  },
};
</script>
<style></style>
