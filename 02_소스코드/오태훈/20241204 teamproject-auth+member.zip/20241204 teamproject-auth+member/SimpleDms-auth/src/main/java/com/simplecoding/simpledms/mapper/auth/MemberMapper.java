package com.simplecoding.simpledms.mapper.auth;

import com.simplecoding.simpledms.vo.auth.Member;
import com.simplecoding.simpledms.vo.basic.Emp;
import com.simplecoding.simpledms.vo.common.Criteria;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;
import java.util.Optional;

/**
 * @author : KTE
 * @fileName : MemberMapper
 * @since : 24. 11. 11.
 * description :
 */
@Mapper
public interface MemberMapper {
    public List<?> selectMemberList(Criteria searchVO);

    public int selectMemberListTotCnt(Criteria searchVO);

    public int insert(Member member);     // 회원가입

    public long existsById(String email); // 우리회원인지 확인

    public Optional<Member> selectMember(String email); // 회원 상세조회

    public int update(Member member);

    public int delete(String email);
}
