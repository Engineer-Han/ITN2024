package com.simplecoding.simpledms.vo.advanced;

import lombok.*;

/**
 * @author : KTE
 * @fileName : FileDb
 * @since : 24. 11. 1.
 * description :
 *   TODO: TB_FILE_DB 테이블 참고
 */
@Setter
@Getter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class Gallery {

    private String uuid;
    private String galleryTitle;
    private String galleryFileUrl;
    private byte[] galleryData;

    public Gallery(String uuid, String galleryTitle, byte[] galleryData) {
        this.uuid = uuid;
        this.galleryTitle = galleryTitle;
        this.galleryData = galleryData;
    }

    public Gallery(String galleryTitle, byte[] galleryData) {
        this.galleryTitle = galleryTitle;
        this.galleryData = galleryData;
    }
}
