package com.simplecoding.simpledms.mapper.advanced;

import com.simplecoding.simpledms.vo.advanced.Gallery;
import com.simplecoding.simpledms.vo.common.Criteria;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;
import java.util.Optional;

/**
 * @author : KTE
 * @fileName : FileDbMapper
 * @since : 24. 11. 1.
 * description :
 */
@Mapper
public interface GalleryMapper {
    public List<?> selectGalleryList(Criteria searchVO); // 전체조회

    public int selectGalleryListTotCnt(Criteria searchVO);

    public int insert(Gallery gallery);

    public Optional<Gallery> selectGallery(String uuid);

    public int update(Gallery gallery);

    public int delete(String uuid);
}
