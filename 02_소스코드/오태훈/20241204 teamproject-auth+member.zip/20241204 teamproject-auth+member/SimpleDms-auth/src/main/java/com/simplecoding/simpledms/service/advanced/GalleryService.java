package com.simplecoding.simpledms.service.advanced;

import com.simplecoding.simpledms.mapper.advanced.GalleryMapper;
import com.simplecoding.simpledms.vo.advanced.Gallery;
import com.simplecoding.simpledms.vo.common.Criteria;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

/**
 * @author : KTE
 * @fileName : FileDbService
 * @since : 24. 11. 1.
 * description :
 */
@Service
@RequiredArgsConstructor
public class GalleryService {
    private final GalleryMapper galleryMapper;

    //    전체조회
    public List<?> selectGalleryList(Criteria searchVO) {
        List<?> page = galleryMapper.selectGalleryList(searchVO);
        int count = galleryMapper.selectGalleryListTotCnt(searchVO);
        searchVO.setTotalItems(count);
        return page;
    }

    public void insert(Gallery gallery) {
        String uuid = UUID.randomUUID().toString();
        String url = generateDownloadUrl(uuid);
        gallery.setUuid(uuid);
        gallery.setGalleryFileUrl(url);
        galleryMapper.insert(gallery);
    }

    public String generateDownloadUrl(String uuid) {
        return ServletUriComponentsBuilder
                .fromCurrentContextPath()
                .path("/api/advanced/gallery/")
                .path(uuid)
                .toUriString();
    }

    public Optional<Gallery> selectGallery(String uuid) {

        return galleryMapper.selectGallery(uuid);
    }

    public void update(Gallery gallery) {
        String uuid = gallery.getUuid();
        String url = generateDownloadUrl(uuid);
        gallery.setUuid(uuid);
        gallery.setGalleryFileUrl(url);
        galleryMapper.update(gallery);
    }

    public void delete(String uuid) {
        galleryMapper.delete(uuid);
    }
}
