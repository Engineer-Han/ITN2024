// services/advanced/FileDbService.js
import axios from "axios";
const baseURL = "http://localhost:8000/api";

// 전체조회
const getAll = (searchKeyword, pageIndex, recordCountPerPage) => {
  return axios.get(
    baseURL +
      `/advanced/fileDb?searchKeyword=${searchKeyword}&pageIndex=${pageIndex}&recordCountPerPage=${recordCountPerPage}`
  );
};
// insert(upload)
// form 태그 : input 양식, multipart 전송
// TODO: form 태그 == FormData 객체
const insertForm = (data)=>{
  console.log(data)
  // FormData 객체 생성
  let formData = new FormData();
  // FormData 객체에 넣기 : .append(키(벡엔드변수명), 값)
  formData.append("fileTitle", data.fileTitle);
  formData.append("fileContent", data.fileContent);
  formData.append("image", data.image);

  return formData;
}
// insert 함수
// 다운로드 함수 : 첨부파일입니다.(헤더명시)
const insert = (data) => {
  let form = insertForm(data);
  return axios.post(baseURL+"/advanced/fileDb/add", form,
    {
      headers: {"Content-Type": "multipart/form-data",}
    }
  );
}

// 상세 조회 : 기본키(uuid)
const get = (uuid)=>{
  return axios.get(baseURL+`/advanced/fileDb/get/${uuid}`);
}
// 수정 
const update = (uuid, data)=>{
  let form = insertForm(data);
  return axios.put(baseURL+`/advanced/fileDb/update/${uuid}`, form,
    {
      headers: {"Content-Type": "multipart/form-data",}
    }
  );  
}
// 삭제
const remove = (uuid)=>{
  return axios.delete(baseURL+`/advanced/fileDb/deletion/${uuid}`);
}
const FileDbService = {
    getAll,
    insert,
    get,
    update,
    remove
}
export default FileDbService;
