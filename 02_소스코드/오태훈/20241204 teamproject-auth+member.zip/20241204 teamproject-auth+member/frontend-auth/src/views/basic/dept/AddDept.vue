// views/basic/dept/AddDept.vue // vueInit
<template>
  <div>
    <!-- dname -->
    <div class="form-floating mb-3">
      <input
        type="text"
        class="form-control"
        id="dname"
        placeholder="dname"
        v-model="dept.dname"
      />
      <label for="dname">dname</label>
    </div>
    <!-- loc -->
    <div class="form-floating mb-3">
      <input
        type="text"
        class="form-control"
        id="loc"
        placeholder="loc"
        v-model="dept.loc"
      />
      <label for="loc">loc</label>
    </div>
    <!-- 버튼 -->
    <button type="button" class="btn btn-primary" @click="save">저장</button>
  </div>
</template>
<script>
import DeptService from "@/services/basic/DeptService";
export default {
  data() {
    return {
      dept: {
        dname: "",
        loc: "",
      },
    };
  },
  methods: {
    async save() {
      try {
        let response = await DeptService.insert(this.dept);
        console.log(response.data); // 디버깅
        // TODO: 저장후 강제이동: 전체조회(/dept)
        this.$router.push("/dept")
      } catch (error) {
        console.log(error);
      }
    },
  },
};
</script>
<style></style>
