// views/basic/emp/EmpDetail.vue // vueInit // 연습) 상세조회 : url(/emp/:eno)
메뉴등록 // 연습2) 디자인 + update() 함수만 만들기 // getDetail() 실행해서
alert(eno) 띄우기 // 연습 2) EmpDetail 상세조회 데이터를 화면에 표시하세요 //
EmpService.js : get() 함수 작성 // EmpDetail.vue : getDetail() 함수 작성 //
연습3) 아래 update() 함수를 작성하세요 // EmpService.js : update() 함수 //
EmpDetail.vue : update() 함수 // 연습4) 아래 remove() 함수 작성 // EmpService.js
: remove() // EmpDetail.vue : remove()
<template>
  <div>
    <!-- TODO: 저장(sql : insert(기본키(eno)(시퀀스가 만듬))) -->
    <!-- ename -->
    <div class="form-floating mb-3">
      <input
        type="text"
        class="form-control"
        id="ename"
        placeholder="ename"
        v-model="emp.ename"
      />
      <label for="ename">ename</label>
    </div>
    <!-- job -->
    <div class="form-floating mb-3">
      <input
        type="text"
        class="form-control"
        id="job"
        placeholder="job"
        v-model="emp.job"
      />
      <label for="job">job</label>
    </div>
    <!-- manager -->
    <div class="form-floating mb-3">
      <input
        type="text"
        class="form-control"
        id="manager"
        placeholder="manager"
        v-model="emp.manager"
      />
      <label for="manager">manager</label>
    </div>
    <!-- hiredate -->
    <div class="form-floating mb-3">
      <input
        type="text"
        class="form-control"
        id="hiredate"
        placeholder="hiredate"
        v-model="emp.hiredate"
      />
      <label for="hiredate">hiredate</label>
    </div>
    <!-- salary -->
    <div class="form-floating mb-3">
      <input
        type="text"
        class="form-control"
        id="salary"
        placeholder="salary"
        v-model="emp.salary"
      />
      <label for="salary">salary</label>
    </div>
    <!-- commission -->
    <div class="form-floating mb-3">
      <input
        type="text"
        class="form-control"
        id="commission"
        placeholder="commission"
        v-model="emp.commission"
      />
      <label for="commission">commission</label>
    </div>
    <!-- dno -->
    <div class="form-floating mb-3">
      <input
        type="text"
        class="form-control"
        id="dno"
        placeholder="dno"
        v-model="emp.dno"
      />
      <label for="dno">dno</label>
    </div>

    <!-- 수정버튼 -->
    <button type="button" class="btn btn-warning me-2" @click="update">
      수정
    </button>
    <!-- 삭제버튼 -->
    <button type="button" class="btn btn-danger" @click="remove">삭제</button>
  </div>
</template>
<script>
import EmpService from "@/services/basic/EmpService";
export default {
  data() {
    return {
      emp: {
        eno: "",
        ename: "",
        manager: "",
        job: "",
        hiredate: "",
        salary: "",
        commission: "",
        dno: "",
      },
    };
  },
  methods: {
    // 함수작성
    // TODO: 상세조회
    async getDetail(eno) {
      try {
        let response = await EmpService.get(eno);
        console.log(response.data); // 디버깅
        this.emp = response.data;
      } catch (error) {
        console.log(error);
      }
    },
    // TODO: 수정
    async update() {
      try {
        let response = await EmpService.update(this.emp.eno, this.emp);
        console.log(response.data); // 디버깅
        this.$router.push("/emp");
      } catch (error) {
        console.log(error);
      }
    },
    // TODO: 삭제
    async remove() {
      try {
        let response = await EmpService.remove(this.emp.eno);
        console.log(response.data); // 디버깅
        // 전체조회 강제이동 : /emp
        this.$router.push("/emp");
      } catch (error) {
        console.log(error);
      }
    },
  },
  mounted() {
    this.getDetail(this.$route.params.eno);
  },
};
</script>
<style></style>
