// 연습 1) views/basic/emp/EmpView.vue // vueInit (메뉴 달기) 화면에 보이기 //
메뉴등록 : router/index.js // url (HeaderCom.vue(머리말)) : /emp (사원) // url
(HeaderCom.vue(머리말)) : /add-emp (사원추가) // 연습 2) 테이블 디자인 , 화면에
표시 // 데이터 (반복문까지 출력 : emps(빈배열)) // services/basic/EmpService.js
: // getAll(searchKeyword, pageIndex, recordCountPerPage) (전체조회)
<template>
  <div>
    <!-- TODO: 검색어 입력상자 -->
    <div class="input-group mb-3">
      <input
        type="text"
        class="form-control"
        placeholder="검색어"
        v-model="searchKeyword"
      />
      <button class="btn btn-outline-secondary" type="button" @click="getEmp">
        검색
      </button>
    </div>
    <!-- TODO: 부트스트랩 테이블(사원) -->
    <table class="table">
      <thead>
        <tr>
          <th scope="col">eno</th>
          <th scope="col">ename</th>
          <th scope="col">job</th>
          <th scope="col">manager</th>
          <th scope="col">hiredate</th>
          <th scope="col">salary</th>
          <th scope="col">commission</th>
          <th scope="col">dno</th>
          <th scope="col">action</th>
        </tr>
      </thead>
      <tbody>
        <!-- TODO: 반복문 : emps -->
        <tr v-for="(data, index) in emps" :key="index">
          <td>{{ data.eno }}</td>
          <td>{{ data.ename }}</td>
          <td>{{ data.job }}</td>
          <td>{{ data.manager }}</td>
          <td>{{ data.hiredate }}</td>
          <td>{{ data.salary }}</td>
          <td>{{ data.commission }}</td>
          <td>{{ data.dno }}</td>
          <td>
            <!-- a태그, router-link태그 -->
            <router-link :to="'/emp/' + data.eno">
              <span class="badge text-bg-success">수정</span>
            </router-link>
          </td>
        </tr>
      </tbody>
    </table>
    <!-- TODO: 페이지 번호 : 부트스트랩뷰(페이지) -->
    <div>
      <b-pagination
        v-model="pageIndex"
        :total-rows="totalCount"
        :per-page="recodeCountPerPage"
        @click="getEmp"
      ></b-pagination>
    </div>
  </div>
</template>
<script>
import EmpService from "@/services/basic/EmpService";
export default {
  data() {
    return {
      pageIndex: 1, // 현재페이지번호
      totalCount: 0, // 전체개수
      recodeCountPerPage: 3, // 화면에보일개수
      searchKeyword: "", // 검색어
      emps: [], // 빈배열(json)
    };
  },
  methods: {
    // 함수작성
    async getEmp() {
      try {
        let response = await EmpService.getAll(
          this.searchKeyword,
          this.pageIndex - 1,
          this.recodeCountPerPage
        );
        // TODO: 벡엔드 전송되는것: results(배열), totalCount(총개수)
        const { results, totalCount } = response.data;
        console.log(response.data); // 디버깅
        this.emps = results;
        this.totalCount = totalCount;
      } catch (error) {
        console.log(error);
      }
    },
  },
  //   화면이 뜰때 자동실행 함수
  mounted() {
    this.getEmp();
  },
};
</script>
<style></style>
