// views/basic/emp/AddEmp.vue // vueInit // 메뉴등록 : url(/add-emp) //
router/index.js(메뉴 등록) // 디자인 및 저장 클릭: alert("테스트") // 2) 연습)
save 함수에 저장기능을 추가하세요 // services/basic/EmpService.js : insert 함수
작성 // views/basic/emp/AddEmp.vue : save 함수 작성
<template>
  <div>
    <!-- TODO: 저장(sql : insert(기본키(eno)(시퀀스가 만듬))) -->
    <!-- ename -->
    <div class="form-floating mb-3">
      <input
        type="text"
        class="form-control"
        id="ename"
        placeholder="ename"
        v-model="emp.ename"
      />
      <label for="ename">ename</label>
    </div>
    <!-- job -->
    <div class="form-floating mb-3">
      <input
        type="text"
        class="form-control"
        id="job"
        placeholder="job"
        v-model="emp.job"
      />
      <label for="job">job</label>
    </div>
    <!-- manager -->
    <div class="form-floating mb-3">
      <input
        type="text"
        class="form-control"
        id="manager"
        placeholder="manager"
        v-model="emp.manager"
      />
      <label for="manager">manager</label>
    </div>
    <!-- hiredate -->
    <div class="form-floating mb-3">
      <input
        type="text"
        class="form-control"
        id="hiredate"
        placeholder="hiredate"
        v-model="emp.hiredate"
      />
      <label for="hiredate">hiredate</label>
    </div>
    <!-- salary -->
    <div class="form-floating mb-3">
      <input
        type="text"
        class="form-control"
        id="salary"
        placeholder="salary"
        v-model="emp.salary"
      />
      <label for="salary">salary</label>
    </div>
    <!-- commission -->
    <div class="form-floating mb-3">
      <input
        type="text"
        class="form-control"
        id="commission"
        placeholder="commission"
        v-model="emp.commission"
      />
      <label for="commission">commission</label>
    </div>
    <!-- dno -->
    <div class="form-floating mb-3">
      <input
        type="text"
        class="form-control"
        id="dno"
        placeholder="dno"
        v-model="emp.dno"
      />
      <label for="dno">dno</label>
    </div>

    <!-- 버튼 -->
    <button type="button" class="btn btn-primary" @click="save">저장</button>
  </div>
</template>
<script>
import EmpService from '@/services/basic/EmpService';
export default {
  data() {
    return {
      emp: {
        ename: "",
        manager: "",
        job: "",
        hiredate: "",
        salary: "",
        commission: "",
        dno: "",
      },
    };
  },
  methods: {
    async save() {
      try {
        let response = await EmpService.insert(this.emp);
        console.log(response.data); // 디버깅
        this.$router.push("/emp");
      } catch (error) {
        console.log(error);
      }
    },
  },
};
</script>
<style></style>
