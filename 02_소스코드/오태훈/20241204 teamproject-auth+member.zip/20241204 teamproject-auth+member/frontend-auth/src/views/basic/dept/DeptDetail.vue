// views/dept/DeptDetail.vue // vueInit
<template>
  <div>
    <!-- dname -->
    <div class="form-floating mb-3">
      <input
        type="text"
        class="form-control"
        id="dname"
        placeholder="dname"
        v-model="dept.dname"
      />
      <label for="dname">dname</label>
    </div>
    <!-- loc -->
    <div class="form-floating mb-3">
      <input
        type="text"
        class="form-control"
        id="loc"
        placeholder="loc"
        v-model="dept.loc"
      />
      <label for="loc">loc</label>
    </div>
    <!-- 수정버튼 -->
    <!-- m : 마진, e(end:오른쪽), s(start:왼쪽) -->
    <button type="button" 
            class="btn btn-warning me-2" 
            @click="update">수정</button>
    <!-- 삭제버튼 -->
    <button type="button" 
            class="btn btn-danger"
            @click="remove"
            >삭제</button>
  </div>
</template>
<script>
import DeptService from '@/services/basic/DeptService';
export default {
    data() {
        return {
            dept: {
                dno:"",   // 기본키
                dname:"",
                loc:""
            },
        }
    },
    methods: {
        // 함수작성
        // TODO: 상세조회
        async getDetail(dno) {
            try {
              let response = await DeptService.get(dno);
              console.log(response.data); // 디버깅
              this.dept = response.data;
            } catch (error) {
              console.log(error);
            }
        },
        // TODO: 수정
        async update(){
          try {
            let response 
               = await DeptService.update(this.dept.dno, this.dept);
            console.log(response.data); // 디버깅
            // 전체조회 강제이동 : /dept
            this.$router.push("/dept");
          } catch (error) {
            console.log(error);
          }
        },
        // TODO: 삭제
        async remove(){
          try {
            let response 
               = await DeptService.remove(this.dept.dno);
            console.log(response.data); // 디버깅
            // 전체조회 강제이동 : /dept
            this.$router.push("/dept");
          } catch (error) {
            console.log(error);
          }
        }
    },
    // 화면이 최초 뜰때 자동실행
    mounted() {
        // 상세조회 : dno(부서번호:기본키)값
        // TODO: 사용법) this.$route.params.변수명
        //  => router/index.js : 메뉴등록 : /dept/:변수명
        this.getDetail(this.$route.params.dno);
    },
};
</script>
<style></style>
