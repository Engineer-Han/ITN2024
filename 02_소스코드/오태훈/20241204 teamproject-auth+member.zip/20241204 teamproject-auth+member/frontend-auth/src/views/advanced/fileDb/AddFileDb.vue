<template>
  <div>
    <!-- fileTitle -->
    <div class="form-floating mb-3">
      <input
        type="text"
        class="form-control"
        id="fileTitle"
        placeholder="fileTitle"
        v-model="fileDb.fileTitle"
      />
      <label for="fileTitle">fileTitle</label>
    </div>
    <!-- fileContent -->
    <div class="form-floating mb-3">
      <input
        type="text"
        class="form-control"
        id="fileContent"
        placeholder="fileContent"
        v-model="fileDb.fileContent"
      />
      <label for="fileContent">fileContent</label>
    </div>
    <!-- TODO: 파일선택상자 -->
    <div class="input-group">
      <input
        type="file"
        class="form-control"
        ref="file"
        @change="select"
      />
      <button
        class="btn btn-outline-secondary"
        type="button"
        @click="save"
      >
        Button
      </button>
    </div>
  </div>
</template>

<script>
import FileDbService from '@/services/advanced/FileDbService';
export default {
  data() {
    return {
      fileDb: {
        fileTitle: "",
        fileContent: "",
        fileUrl: "", // 다운로드 url
        image: undefined, // 선택이미지
      },
    };
  },
  methods: {
    select(){
      // 파일선택상자에서 선택한 이미지를 저장
      // TODO: 파일선택상자 태그 : input type="file"
      // 특징 : 첫번째 선택하면(이미지) files[0] 배열에 저장 
      // 사용법 : this.$refs.태그변수 : html 태그 접근
      this.fileDb.image = this.$refs.file.files[0];
    },
    async save(){
      try {
        let response = await FileDbService.insert(this.fileDb);
        console.log(response.data); // 디버깅
        // insert 성공 -> 전체조회 강제 이동
        this.$router.push("/fileDb");
      } catch (error) {
        this.fileDb.image = undefined;
        console.log(error);
      }
    }
  },
};
</script>
<style></style>
