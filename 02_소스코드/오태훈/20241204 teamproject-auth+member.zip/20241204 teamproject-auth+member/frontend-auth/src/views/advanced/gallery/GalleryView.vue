// views/advanced/gallery/GalleryView.vue // vueInit // 디자인 및 변수/함수
형태만 코딩
<template>
  <div>
    <!-- TODO: 검색어 입력상자 -->
    <div class="input-group mb-3">
      <input
        type="text"
        class="form-control"
        placeholder="검색어"
        v-model="searchKeyword"
      />
      <button
        class="btn btn-outline-secondary"
        type="button"
        @click="getGallery"
      >
        검색
      </button>
    </div>
    <!-- TODO: 카드 -->
    <div class="row">
      <div v-for="(data, index) in galleries" :key="index" class="col-6">
        <div class="card" style="width: 18rem">
          <img :src="data.galleryFileUrl" class="card-img-top" alt="카드" />
          <div class="card-body">
            <h5 class="card-title">{{ data.galleryTitle }}</h5>
            <router-link :to="'/gallery/' + data.uuid" class="btn btn-primary">
              수정
            </router-link>
          </div>
        </div>
      </div>
    </div>
    <!-- TODO: 페이지 번호 : 부트스트랩뷰(페이지)  -->
    <div class="mt-3">
      <b-pagination
        v-model="pageIndex"
        :total-rows="totalCount"
        :per-page="recodeCountPerPage"
        @click="getGallery"
      ></b-pagination>
    </div>
  </div>
</template>
<script>
import GalleryService from "@/services/advanced/GalleryService";
export default {
  data() {
    return {
      pageIndex: 1,
      totalCount: 0,
      recodeCountPerPage: 3,
      searchKeyword: "",
      galleries: [], // 빈배열
    };
  },
  methods: {
    async getGallery() {
      try {
        let response = await GalleryService.getAll(
          this.searchKeyword,
          this.pageIndex - 1,
          this.recodeCountPerPage
        );
        // TODO: 벡엔드 전송되는것: results(배열), totalCount(총개수)
        const { results, totalCount } = response.data;
        console.log(response.data); // 디버깅
        this.galleries = results;
        this.totalCount = totalCount;
      } catch (error) {
        console.log(error);
      }
    },
  },
  mounted() {
    this.getGallery();
  },
};
</script>
<style></style>
