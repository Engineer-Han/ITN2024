// AddGallery.vue // 연습) 메뉴 등록 및 디자인 // vueInit
<template>
  <div>
    <!-- galleryTitle -->
    <div class="form-floating mb-3">
      <input
        type="text"
        class="form-control"
        id="galleryTitle"
        placeholder="galleryTitle"
        v-model="gallery.galleryTitle"
      />
      <label for="galleryTitle">galleryTitle</label>
    </div>
    <!-- TODO: 파일선택상자 -->
    <div class="input-group">
      <input type="file" class="form-control" ref="file" @change="select" />
      <button class="btn btn-outline-secondary" type="button" @click="save">
        Button
      </button>
    </div>
  </div>
</template>
<script>
import GalleryService from "@/services/advanced/GalleryService";
export default {
  data() {
    return {
      gallery: {
        galleryTitle: "",
        galleryFileUrl: "", // 다운로드 url
        image: undefined, // 선택이미지
      },
    };
  },
  methods: {
    select() {
      this.gallery.image = this.$refs.file.files[0];
    },
    async save() {
      try {
        let response = await GalleryService.insert(this.gallery);
        console.log(response.data); // 디버깅
        // insert 성공 -> 전체조회 강제 이동
        this.$router.push("/gallery");
      } catch (error) {
        this.gallery.image = undefined;
        console.log(error);
      }
    },
  },
};
</script>
<style></style>
