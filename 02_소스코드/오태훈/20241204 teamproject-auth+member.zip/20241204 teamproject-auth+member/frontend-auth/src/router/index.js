import { createRouter, createWebHistory } from 'vue-router'
import HomeView from '../views/HomeView.vue'

const routes = [
  {
    path: '/',
    component: HomeView
  },
  {
    path: '/about',
    component: () => import('../views/AboutView.vue')
  },
  {
    // path: /register, component(RegisterView.vue)
    path: '/register',
    component: () => import('../views/auth/RegisterView.vue')
  },
  {
    // path: /login, component(LoginView.vue)
    path: '/login',
    component: () => import('../views/auth/LoginView.vue')
  }
  // todo: 여기
  ,
  {
    // 부서 메뉴 등록 : path(/dept), component(DeptView.vue)
    path: '/dept',
    component: () => import('../views/basic/dept/DeptView.vue')
  },
  {
    // 부서 메뉴 등록 : path(/add-dept), component(AddDept.vue)
    path: '/add-dept',
    component: () => import('../views/basic/dept/AddDept.vue')
  },
  {
    // path(/dept/:dno), component(DeptDetail.vue)
    path: '/dept/:dno',
    component: () => import('../views/basic/dept/DeptDetail.vue')
  },
  {
    path: '/emp',
    component: () => import('../views/basic/emp/EmpView.vue')
  },
  {
    // path(/add-emp), component(AddEmp.vue)
    path: '/add-emp',
    component: () => import('../views/basic/emp/AddEmp.vue')
  },
  {
    // path(/emp/:eno), component(EmpDetail.vue)
    path: '/emp/:eno',
    component: () => import('../views/basic/emp/EmpDetail.vue')
  },
  {
    // path(/fileDb), component(FileDbView.vue)
    path: '/fileDb',
    component: () => import('../views/advanced/fileDb/FileDbView.vue')
  },
  {
    // path(/add-fileDb), component(AddFileDb.vue)
    path: '/add-fileDb',
    component: () => import('../views/advanced/fileDb/AddFileDb.vue')
  },
  {
    // path(/fileDb/:uuid), component(FileDbDetail.vue)
    path: '/fileDb/:uuid',
    component: () => import('../views/advanced/fileDb/FileDbDetail.vue')
  },
  {
    // path(/gallery), component(GalleryView.vue)
    path: '/gallery',
    component: () => import('../views/advanced/gallery/GalleryView.vue')
  },
  {
    // path(/add-gallery), component(AddGallery.vue)
    path: '/add-gallery',
    component: () => import('../views/advanced/gallery/AddGallery.vue')
  },
  {
    // path(/gallery/:uuid), component(GalleryDetail.vue)
    path: '/gallery/:uuid',
    component: () => import('../views/advanced/gallery/GalleryDetail.vue')
  }
]

const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes
})

export default router
