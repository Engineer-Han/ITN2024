// services/auth/MemberService.js
import axios from "axios";

const baseURL = "http://localhost:8000/api"

// 전체조회
const getAll = (searchKeyword, pageIndex, recordCountPerPage) => {
    return axios
        .get(baseURL + `/auth/member?searchKeyword=${searchKeyword}&pageIndex=${pageIndex}&recordCountPerPage=${recordCountPerPage}`);
};
const get = (email) => {
    return axios.get(baseURL + `/auth/member/${email}`);
}

const MemberService = {
    getAll, get
}
export default MemberService;