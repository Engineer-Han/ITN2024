<template>
  <div>
    <h3>회원 정보 관리</h3>
    <hr/>

    <br/>
    <br/>

    <h3>회원 검색</h3>
    <br/>

    <table class="table table-bordered table-sm">
      <tbody>
      <tr>
        <th scope="row">검색어</th>
        <td>
          <div class="row align-items-center">
            <div class="col-auto">
              <select
                  class="form-select"
                  aria-label=".form-select example"
                  id="search-select"
                  v-model="searchCriteria"
              >
                <option selected>검색어 선택</option>
                <option value="email">아이디(Email)</option>
                <option value="name">이름</option>
                <option value="phoneNumber">전화번호</option>
              </select>
            </div>
            <div class="col">
              <input type="text"
                     class="form-control"
                     id="search-input"
                     placeholder="검색어를 입력하세요"
                     aria-label="검색어"
                     aria-describedby="button-addon2"
                     v-model="searchKeyword"
              >
            </div>
          </div>
        </td>
      </tr>
      </tbody>
    </table>

    <div class="text-center">
      <button type="button"
              class="btn btn-primary btn-sm me-2"
              @click="getMember"
      >
        검색
      </button>
      <button type="button"
              class="btn btn-primary btn-sm me-2"
              @click="resetSearch"
      >
        초기화
      </button>
    </div>

    <br/>
    <br/>

    <h3>회원 정보 리스트</h3>
    <hr/>

    <table class="table">
      <thead>
      <tr class="table-secondary">
        <th scope="col">ID(Email)</th>
        <th scope="col">전화번호</th>
        <th scope="col">이름</th>
        <th scope="col">Grade</th>
        <th scope="col">가입 일시</th>
      </tr>
      </thead>
      <tbody>
      <tr v-for="(data, index) in members" :key="index">
        <td>{{ data.email }}</td>
        <td>{{ data.phoneNumber }}</td>
        <td>{{ data.name }}</td>
        <td>{{ data.codeName }}</td>
        <td>{{ data.insertTime }}</td>
      </tr>
      </tbody>
    </table>

    <br/>
    <br/>

    <div>
      <b-pagination
          class="justify-content-center"
          v-model="pageIndex"
          :total-rows="totalCount"
          :per-page="recodeCountPerPage"
          @click="getMember"
      ></b-pagination>
    </div>

    <br/>
    <br/>
  </div>
</template>

<script>
import MemberService from "@/services/auth/MemberService";

export default {
  data() {
    return {
      pageIndex: 1, // 현재페이지번호
      totalCount: 0, // 전체개수
      recodeCountPerPage: 3, // 화면에보일개수
      searchKeyword: "", // 검색어
      searchCriteria: "", // 검색 기준 (아이디, 이름, 전화번호)
      members: [], // 빈배열(json)
    };
  },
  methods: {
    // 함수작성
    async getMember() {
      try {
        let response = await MemberService.getAll(
            this.searchKeyword,
            this.pageIndex - 1,
            this.recodeCountPerPage
        );
        // TODO: 벡엔드 전송되는것: results(배열), totalCount(총개수)
        const {results, totalCount} = response.data;
        console.log(response.data); // 디버깅
        this.members = results;
        this.totalCount = totalCount;

      } catch (error) {
        console.log(error);
      }
    },

    // 초기화 버튼을 클릭했을 때 호출되는 메소드
    resetSearch() {
      this.searchKeyword = "";  // 검색어 초기화
      this.searchCriteria = ""; // 검색 기준 초기화
      document.getElementById('search-select').selectedIndex = 0; // 검색어 선택 초기화
    }
  },
  // 화면이 뜰때 자동실행 함수
  mounted() {
    this.getMember();
  },
};
</script>

<style></style>
