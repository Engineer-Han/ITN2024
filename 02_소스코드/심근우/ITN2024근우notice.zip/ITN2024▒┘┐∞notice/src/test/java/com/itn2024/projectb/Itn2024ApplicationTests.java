package com.itn2024.projectb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Itn2024ApplicationTests {

    @Test
    void contextLoads() {
    }

}
