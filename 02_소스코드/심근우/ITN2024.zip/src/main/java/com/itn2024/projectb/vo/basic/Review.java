package com.itn2024.projectb.vo.basic;

import lombok.*;

/**
 * @author : dlfdl
 * @fileName : Emp
 * @since : 24. 10. 23.
 * description :
 */
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class Review {
    private String rvid;            // 고유ID(기본키)
    private String prid;       // 상품ID
    private String contents;         // 내용
    private String writer;        // 작성자



}