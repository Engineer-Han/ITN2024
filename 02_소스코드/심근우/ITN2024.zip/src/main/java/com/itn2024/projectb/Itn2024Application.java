package com.itn2024.projectb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Itn2024Application {

    public static void main(String[] args) {
        SpringApplication.run(Itn2024Application.class, args);
    }

}
