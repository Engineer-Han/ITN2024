package com.itn2024.projectb.controller.basic;


import com.itn2024.projectb.service.basic.ReviewService;
import com.itn2024.projectb.vo.basic.Review;
import com.itn2024.projectb.vo.common.Criteria;
import com.itn2024.projectb.vo.dto.ResultDto;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

/**
 * @author : dlfdl
 * @fileName : DeptController
 * @since : 24. 10. 23.
 * description :
 */
@RestController
@RequiredArgsConstructor
public class ReviewController {
    private final ReviewService reviewService; // 서비스 객체

    //    전체 조회
    @GetMapping("/api/basic/review")
    public ResponseEntity<?> selectReviewList(Criteria searchVO) {
        List<?> reviews = reviewService.selectReviewList(searchVO);

//      TODO: depts(배열) 1개 + 총건수 1개 -> 박스포장용 객체
//          객체생성(택배박스: DTO 객체) : 속성필드 (배열), 속성필드(총건수)
        ResultDto resultDto
                = new ResultDto(reviews, searchVO.getTotalItems());
//      TODO: 상태코드 : HttpStatus.OK, NO_CONTENT ...
        return new ResponseEntity<>(resultDto, HttpStatus.OK);
    }



    //    부서 생성
//    TODO: spring :객체를 매개변수로 받는 어노테이션 : @ModelAttribute
//    TODO: springboot :객체를 매개변수로 받는 어노테이션 : @RequestBody
    @PostMapping("/api/basic/review")
    public ResponseEntity<?> insert(
            @RequestBody Review review
    ) {
        reviewService.insert(review);

        return new ResponseEntity<>(HttpStatus.OK);
    }



    // 부서 상세조회
    //    TODO: 쿼리스트링 : http://localhost:8000/dept?dno=10
    //         spring   : 어노테이션 : @RequestParam
    //        파라메터방식 : http://localhost:8000/dept/10
    //       springboot :  어노테이션 : @PathVariable
    @GetMapping("/api/basic/review/{rvid}")
    public ResponseEntity<?> selectReview(
            @PathVariable String rvid
    ){
        Optional<Review> review = reviewService.selectReview(rvid);
        // 에러처리 : dept 가  null 이면?
        if (review.isEmpty()){
         return new ResponseEntity<>(HttpStatus.NOT_FOUND);

        }
        return new ResponseEntity<>(review.get(), HttpStatus.OK);
    }

//    부서 수정
    @PutMapping("/api/basic/review/{rvid}")
    public ResponseEntity<?> update(
            @PathVariable String rvid,
            @RequestBody Review review
    ) {
        reviewService.update(review);
        return new ResponseEntity<>(HttpStatus.OK);
    }

//    부서 삭제
    @DeleteMapping("/api/basic/review/{rvid}")
    public ResponseEntity<?> delete(
            @PathVariable String rvid
    ) {
        reviewService.delete(rvid);
        return new ResponseEntity<>(HttpStatus.OK);
    }


}


