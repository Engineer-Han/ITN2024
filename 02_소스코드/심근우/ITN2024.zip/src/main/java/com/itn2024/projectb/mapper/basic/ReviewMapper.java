package com.itn2024.projectb.mapper.basic;

import com.itn2024.projectb.vo.basic.Review;
import com.itn2024.projectb.vo.common.Criteria;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;
import java.util.Optional;

/**
 * @author : KTE
 * @fileName : DeptMapper
 * @since : 24. 10. 23.
 * description : 부서 매퍼
 */
@Mapper
public interface ReviewMapper {
    public List<?> selectReviewList(Criteria searchVO); // 전체조회
    public int selectReviewListTotCnt(Criteria searchVO);
    public int insert(Review review);                       //
    public Optional<Review> selectReview(String rvid);          // 상세조회
public int update(Review review);                           // 업데이트
    public int delete(String rvid);                       // 삭제
}
