package com.itn2024.projectb.controller.advanced;

import com.itn2024.projectb.service.advanced.CartService;
import com.itn2024.projectb.vo.advanced.Cart;
import com.itn2024.projectb.vo.basic.Notice;
import com.itn2024.projectb.vo.common.Criteria;
import com.itn2024.projectb.vo.dto.CartDto;
import com.itn2024.projectb.vo.dto.ResultDto;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.FileNotFoundException;
import java.util.List;
import java.util.Optional;

/**
 * @author : dlfdl
 * @fileName : GalleryMapper
 * @since : 24. 11. 1.
 * description :
 */


@RestController
@RequiredArgsConstructor
public class CartController {

    private final CartService cartService;  // 서비스 객체

    // 전체조회
    @GetMapping("/api/advanced/cart")
    public ResponseEntity<?> selectCartList(Criteria searchVO) {
        List<?> carts = cartService.selectCartList(searchVO);

//      TODO: depts(배열) 1개 + 총건수 1개 -> 박스포장용 객체
//          객체생성(택배박스: DTO 객체) : 속성필드 (배열), 속성필드(총건수)
        ResultDto resultDto
                = new ResultDto(carts, searchVO.getTotalItems());

//      TODO: 상태코드 : HttpStatus.OK, NO_CONTENT ...
        return new ResponseEntity<>(resultDto, HttpStatus.OK);
    }


    // 삭제
    @DeleteMapping("/api/advanced/cart/delete/{caid}")
    public ResponseEntity<?> delete(
            @PathVariable String caid
    ) {
        cartService.delete(caid);
        return new ResponseEntity<>(HttpStatus.OK);
    }
   

    //    부서 생성
//    TODO: spring :객체를 매개변수로 받는 어노테이션 : @ModelAttribute
//    TODO: springboot :객체를 매개변수로 받는 어노테이션 : @RequestBody
    @PostMapping("/api/advanced/cart")
    public ResponseEntity<?> insert(
            @RequestBody Cart cart
    ) {
        cartService.insert(cart);

        return new ResponseEntity<>(HttpStatus.OK);
    }
//
//    //    상세조회
//    @GetMapping("/api/advanced/cart/get/{caid}")
//    public ResponseEntity<?> selectCart(
//            @PathVariable String caid
//    ) {
//        Optional<Cart> cart = cartService.selectCart(caid);
//        if(cart.isEmpty()) {
//            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
//        }
//        return new ResponseEntity<>(cart.get(), HttpStatus.OK);
//    }
//
//
//
//    //    TODO: 이미지 다운로드 함수
//    //      springboot : json 데이터 => body 쪽에 넣어서 전송
//    @GetMapping("/api/advanced/cart/{caid}")
//    public ResponseEntity<byte[]> findDownload(
//            @PathVariable String caid) throws Exception {
////      1) 상세조회 : 객체받기(첨부파일)
//        Cart cart
//                = cartService.selectCart(caid)
//                .orElseThrow(()-> new FileNotFoundException("데이터 없습니다."));
//
////      2) 첨부파일 jsp 전송 : 규격대로 전송(코딩 보냄)
//        // 우편물 보낼때 규칙과 유사 :
//        HttpHeaders headers = new HttpHeaders();                  // html 문서 객체(머리말)
//        headers.setContentDispositionFormData("attachment", cart.getCaid()); // 첨부파일(문서형태)
//        headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);              // 첨부파일2(문서형태)
//
////       첨부파일 전송 + OK 신호 보냄
//        return new ResponseEntity<byte[]>(cart.getBasketData(), headers, HttpStatus.OK);
//    }
//
//
//
//


    //    부서 수정
    @PutMapping("/api/advanced/cart/{caid}")
    public ResponseEntity<?> update(
            @PathVariable int caid,
            @RequestBody Cart cart
    ) {
        cartService.update(cart);
        return new ResponseEntity<>(HttpStatus.OK);
    }

}



