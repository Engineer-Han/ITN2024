package com.itn2024.projectb.service.basic;

import com.itn2024.projectb.mapper.basic.ReviewMapper;
import com.itn2024.projectb.vo.basic.Review;
import com.itn2024.projectb.vo.common.Criteria;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

/**
 * @author : dlfdl
 * @fileName : EmpService
 * @since : 24. 10. 23.
 * description :
 */
@Service
@RequiredArgsConstructor
public class ReviewService {
    private final ReviewMapper reviewMapper; // DI(객체 받아오기)

    //    TODO: 전체조회
    public List<?> selectReviewList(Criteria searchVO) {
        List<?> page = reviewMapper.selectReviewList(searchVO);

        //        총건수 저장 : Criteria의  totalItems
        int count = reviewMapper.selectReviewListTotCnt(searchVO);
        searchVO.setTotalItems(count);
        return page;
    }


    //    TODO: 부서생성
//     좋은코딩 : 남이 봤는데 가장 간단한 코딩
    public void insert(Review review) {
        reviewMapper.insert(review);
    }


    // TODO: 부서 상세조회
    public Optional<Review> selectReview(String rvid){
        return reviewMapper.selectReview(rvid);
    }
    // TODO: 업데이트
    public void update(Review review){
         reviewMapper.update(review);
    }

    // TODO: 삭제
    public void delete(String rvid){
         reviewMapper.delete(rvid);
    }


}