package com.itn2024.projectb.vo.advanced;

import lombok.*;

/**
 * @author : dlfdl
 * @fileName : Gallery
 * @since : 24. 11. 1.
 * description :
 */
@Setter
@Getter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class Cart {

    private String caid;                // 기본키
    private String prid;       // 제목
    private String siid;        // 업로드파일
    private String color;    // 다운로드 url
    private int quantity;    // 다운로드 url
    private String email;    // 다운로드 url



}






