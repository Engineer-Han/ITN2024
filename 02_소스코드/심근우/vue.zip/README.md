# 부트스트랩 : 페이징 ui설치

# 1)부트스트랩 npm설치 : 5.2.3버전

npm install bootstrap@5.2.3

# 2) 부트스트랩뷰 -3 버젼설치 :

npm install bootstrap-vue-3

# 3) import : main.js
// TODO: bootstrap import
import 'bootstrap/dist/js/bootstrap.bundle'
import 'bootstrap/dist/css/bootstrap.min.css'

// TODO: bootstartp vue3 import
import BootstrapVue3 from 'bootstrap-vue-3'
import 'bootstrap-vue-3/dist/bootstrap-vue-3.css'

.use(BootstrapVue3)

# 4) json 읽는 라이브러리 : axios 설치
   npm i axios

# 참고) 설치 제거 : 
   npm uninstall 라이브러리명

   # 프론트 : vue        : http://localhost:8080/ 
   # 벡앤드 : springboot : http://localhost:8000/ 