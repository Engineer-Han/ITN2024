<template>
  <div>
   준병 주식 왕
   15% 먹음
  </div>
</template>
<script>
export default {
  
}
</script>
<style>
  
</style>