<template>
    <div>
        <!-- ENAME -->
    <div class="form-floating mb-3">
      <input type="text" 
             class="form-control" 
             id="ename" 
             placeholder="ename" 
             v-model="productReview.ename"
             />
      <label
            for="floatingInput"
            @click="save"
                >ename</label>
    </div>

    <!-- JOB -->
    <div class="form-floating mb-3">
      <input type="text" 
             class="form-control" 
             id="job" 
             placeholder="job" 
             v-model="review.job"
             />
      <label
            for="floatingInput"
            @click="save"
                >job</label>
    </div>
    
        <!-- MANAGER --> 
        <div class="form-floating mb-3">
      <input type="text" 
             class="form-control" 
             id="manager" 
             placeholder="manager" 
             v-model="review.manager"
             />
      <label
            for="floatingInput"
            @click="save"
                >manager</label>
    </div>
    
    <!-- HIREDATE -->
    <div class="form-floating mb-3">
      <input type="text" 
             class="form-control" 
             id="hiredate" 
             placeholder="hiredate" 
             v-model="review.hiredate"
             />
      <label
            for="floatingInput"
            @click="save"
                >hiredate</label>
    </div>
    <!-- SALARY -->
    <div class="form-floating mb-3">
      <input type="text" 
             class="form-control" 
             id="salary" 
             placeholder="salary" 
             v-model="review.salary"
             />
      <label
            for="floatingInput"
            @click="save"
                >salary</label>
    </div>
    
    <!-- COMMISSION -->
    <div class="form-floating mb-3">
      <input type="text" 
             class="form-control" 
             id="commission" 
             placeholder="commission" 
             v-model="review.commission"
             />
      <label
            for="floatingInput"
            @click="save"
                >commission</label>
    </div>
    
    <!-- DNO -->
    <div class="form-floating mb-3">
      <input type="text" 
             class="form-control" 
             id="dno" 
             placeholder="dno" 
             v-model="review.dno"
             />
      <label
            for="floatingInput"
            @click="save"
                >dno</label>
    </div>
    

    <!-- 버튼 -->
    <button 
            type="button"  
            class="btn btn-primary"
           @click="save">Save</button>
    
    </div>
</template>
<script>
import ReviewService from "@/services/basic/ReviewService";
export default {
    data() {
        return {
            review: {
                ename: "",
                job: "",
                manager: "",
                hiredate: "",
                salary: "",
                commission: "",
                dno: ""
            },
        };
    },
    methods: {
        async save() {
            
            try {
                let temp = {
                    ename: this.review.ename,
                    job: this.review.job,
                    manager: this.review.manager,
                    hiredate: this.review.hiredate,
                    salary: this.review.salary,
                    commission: this.review.commission,
                    dno:this.review.dno
                }
                let response = await ReviewService.insert(temp);
                console.log(response.data);
                this.$router.push("/review");
            } catch (error) {
                console.log(error);
            }
        },
    },
};
</script>
<style>
    
</style>