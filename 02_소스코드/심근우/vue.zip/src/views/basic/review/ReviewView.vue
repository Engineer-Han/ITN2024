// views-basic-dept/DeptView.vue // vueInit
<template>
  
  <div class="container mb-3">
    <h2 class="text-center">상품리뷰</h2>
  </div>

  <div>
    
    <!-- TODO: 부트스트랩 테이블 -->
    <table class="table">
  <thead class="table bg-light">
    
        <tr>
          
          <th class="col" scope="col">번호</th>
          <th class="col" scope="col">상품정보</th>
          <th class="col" scope="col">제목</th>
          <th class="col" scope="col">작성자</th>
          <th class="col" scope="col">작성일</th>
          
        </tr>
      </thead>
  
   
  

  
      
      <tbody>
        <!-- TODO: 반복문 : depts -->
        <tr v-for="(data, index) in reviews" :key="index">
          <td>{{ calculateIndex(index)}}</td>
          <td>
            <router-link :to='"/review/" + data.rvid'>
              {{ data.prid }}
            </router-link></td>
          <td>{{ data.prid }}</td>
          <td>
            <!-- a태그, router-link태그 -->
            {{ data.writer }}
            
          </td>
          <td>
            <!-- a태그, router-link태그 -->
            {{ data.insertTime }}
            
          </td>
        </tr>
      </tbody>
    </table>

    <!-- TODO: 검색어 입력상자 -->
     
    <div class="w-25 p-3 input-group mb-3 ">
     
     <input
       type="text"
       class="form-control"
       placeholder="검색어"
       v-model="searchKeyword"
     />
     <button class="btn btn-outline-secondary" type="button" @click="getReview">
       검색
     </button>
   </div>
    <!-- TODO: 페이지 번호 : 부트스트랩뷰(페이지)  -->
    <div>
      <!-- TODO: v-model="뷰변수(현재페이지번호)"
                 ,total-rows="전체개수"
                 ,per-page="1페이지당화면에보일개수"
                    -->
      <b-pagination
        v-model="pageIndex"
        :total-rows="totalCount"
        :per-page="recordCountPerPage"
        @click="getReview"
      ></b-pagination>
    </div>
  </div>

</template>
<script>
// 프론트 코딩 : 벡엔드(변수들 보내고) -> 벡엔드(sql 결과 리턴)
//              -> 프론트(json 반복문으로 화면출력)
// @ == src 폴더위치(절대경로)
import ReviewService from "@/services/basic/ReviewService";
export default {
  data() {
    return {
      pageIndex: 1, // 현재페이지번호
      totalCount: 0, // 전체개수
      recordCountPerPage: 10, // 화면에보일개수
      searchKeyword: "", // 검색어
      reviews: [] // 빈배열(json)
    };
  },





  computed: {
    pagedItems() {
      const start = (this.pageIndex - 1) * this.recordCountPerPage;
      const end = start + this.recordCountPerPage;
      return this.items.slice(start, end);
    },
  },
  methods: {

    calculateIndex(index) {
      return (this.pageIndex - 1) * this.recordCountPerPage + index + 1;
    },

    // 함수 작성 : (비동기 코딩: async/await)
    // (복습) : 뷰함수 앞에 : async, axios 함수 앞에 : await
    async getReview() {
      try {
        let response = await ReviewService.getAll(
          this.searchKeyword,
          this.pageIndex - 1,
          this.recordCountPerPage
        );
        // TODO: 벡엔드 전송되는것: results(배열), totalCount(총개수)
        const { results, totalCount } = response.data;
        console.log(response.data); // 디버깅
        this.notices = results;
        this.totalCount = totalCount;
      } catch (error) {
        console.log(error);
      }
      console.log(`Fetching data for page ${this.pageIndex}`);
      // 필요한 경우, 서버에서 데이터를 다시 로드
    },
  },
  // 화면이 뜰때 실행하는 함수
  mounted() {
    this.getReview();
  },
};
</script>
<style>
.table{
  font-size: 12px;
}

</style>
