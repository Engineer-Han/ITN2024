<template>
  <div>
    <!-- ENAME -->
    <div class="form-floating mb-3">
      <input
        type="text"
        class="form-control"
        id="ename"
        placeholder="ename"
        v-model="review.ename"
      />
      <label for="floatingInput" @click="save">ename</label>
    </div>

    <!-- JOB -->
    <div class="form-floating mb-3">
      <input
        type="text"
        class="form-control"
        id="job"
        placeholder="job"
        v-model="review.job"
      />
      <label for="floatingInput" @click="save">job</label>
    </div>

    <!-- MANAGER -->
    <div class="form-floating mb-3">
      <input
        type="text"
        class="form-control"
        id="manager"
        placeholder="manager"
        v-model="review.manager"
      />
      <label for="floatingInput" @click="save">manager</label>
    </div>

    <!-- HIREDATE -->
    <div class="form-floating mb-3">
      <input
        type="text"
        class="form-control"
        id="hiredate"
        placeholder="hiredate"
        v-model="review.hiredate"
      />
      <label for="floatingInput" @click="save">hiredate</label>
    </div>
    <!-- SALARY -->
    <div class="form-floating mb-3">
      <input
        type="text"
        class="form-control"
        id="salary"
        placeholder="salary"
        v-model="review.salary"
      />
      <label for="floatingInput" @click="save">salary</label>
    </div>

    <!-- COMMISSION -->
    <div class="form-floating mb-3">
      <input
        type="text"
        class="form-control"
        id="commission"
        placeholder="commission"
        v-model="review.commission"
      />
      <label for="floatingInput" @click="save">commission</label>
    </div>

    <!-- DNO -->
    <div class="form-floating mb-3">
      <input
        type="text"
        class="form-control"
        id="dno"
        placeholder="dno"
        v-model="review.dno"
      />
      <label for="floatingInput" @click="save">dno</label>
    </div>

    <!-- 수정 버튼 -->
    <button type="button" class="btn btn-warning me-2" @click="update">
      수정
    </button>

    <!-- 삭제 버튼 -->
    <button type="button" class="btn btn-danger" @click="remove">삭제</button>
  </div>
</template>
<script>
import ReviewService from "@/services/basic/ReviewService";
export default {
  data() {
    return {
      review: {
        eno: "",
        ename: "",
        job: "",
        manager: "",
        hiredate: "",
        salary: "",
        commission: "",
        dno: "",
      },
    };
  },
  methods: {
    async getDetail(eno) {
      // 상세조회 :eno
      try {
            let response = await ReviewService.get(eno);
            console.log(response.data);
            this.review = response.data;
           } catch (error) {
            console.log(error);
           }
        },
    // TODO: 수정
    async update() {
      try {
        // let temp = {
        //     eno: this.emp.eno,
        //   ename: this.emp.ename,    
        //   job: this.emp.job,
        //   manager: this.emp.manager,
        //   hiredate: this.emp.hiredate,
        //   salary: this.emp.salary,
        //   commission: this.emp.commission,
        //   dno: this.emp.dno
        // };

        let response = await ReviewService.update(this.review.eno, this.review);
        console.log(response.data);
        this.$router.push("/review");
      } catch (error) {
        console.log(error);
      }
    },
    // TODO : 삭제
    async remove() {
      try {
        // let temp = {
        //     ename: this.emp.ename,    
        //   job: this.emp.job,
        //   manager: this.emp.manager,
        //   hiredate: this.emp.hiredate,
        //   salary: this.emp.salary,
        //   commission: this.emp.commission,
        //   dno: this.emp.dno
        // };

        let response = await ReviewService.remove(this.review.eno, this.review);
        console.log(response.data);
        this.$router.push("/review");
      } catch (error) {
        console.log(error);
      }
    },
  },
  mounted() {
    // 상세조회 :eno(부서번호:기본키)값
    this.getDetail(this.$route.params.eno);
  },
};
</script>
<style></style>
