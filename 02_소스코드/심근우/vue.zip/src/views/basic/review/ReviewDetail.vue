
<template>
  <div class="container mb-3">
    <h2 class="text-center">상품리뷰</h2>
  </div>
  <div class="bold-line"></div>

  <div>
    <div>
      
      
      <div class="container text-start">
        <div class="row">
          <h5 class="title">{{ review.prid }}</h5>
          <div class="col-1 .col-md-4">
            <p class="fw-bold">{{ review.writer }}  </p>
          </div>
          <div class="col-2 .col-md-4">
            <p class="insertTime">&nbsp; &nbsp; &nbsp;{{ review.insertTime }}</p>
          </div>          
        </div>
      </div>
    </div>
  </div>
  <hr />
  <br>

  <div class="container">
    <div class="text-center ">
      <img :src="review.imageUrl" class="" alt="이미지 " />
      </div>
      <br>
      <br>

<div class="text-center">
     <p> {{ review.contents }}</p>
</div>
<!-- 수정 버튼 (작성자나 관리자만 수정 가능) -->
<button v-if="canEdit" type="button" class="btn btn-warning me-2" @click="update">
      수정
    </button>

    <!-- 삭제 버튼 (작성자나 관리자만 삭제 가능) -->
    <button v-if="canEdit" type="button" class="btn btn-danger" @click="remove">
      삭제
    </button>
  </div>
</template>
<script>
import ReviewService from "@/services/basic/ReviewService";

export default {
  data() {
    return {
      review: {
        rvid: "",
        prid: "",
        writer: "",
        contents: "",
        insertTime: "",
        updateTime: "",
      },
      currentUser: null, // 현재 사용자 정보
      canEdit: false, // 수정 가능 여부
    };
  },

  methods: {
    // 현재 사용자 정보 가져오기
    getCurrentUser() {
      // 예시로 Vuex에서 사용자 정보를 가져오는 경우
      this.currentUser = this.$store.state.user;
    },

    // 리뷰 상세 정보 가져오기
    async getDetail(rvid) {
      try {
        let response = await ReviewService.get(rvid);
        this.review = response.data;
        this.checkPermissions();
      } catch (error) {
        console.log(error);
      }
    },

    // 수정 및 삭제 버튼을 사용할 수 있는지 확인
    checkPermissions() {
      // 현재 사용자가 작성자이거나 관리자일 경우 수정 및 삭제 가능
      if (this.currentUser) {
        this.canEdit = this.currentUser.id === this.review.writer || this.currentUser.role === 'admin';
      }
    },

    // 리뷰 수정
    async update() {
      try {
        let response = await ReviewService.update(this.review.rvid, this.review);
        console.log(response.data);
        this.$router.push("/review");
      } catch (error) {
        console.log(error);
      }
    },

    // 리뷰 삭제
    async remove() {
      try {
        let response = await ReviewService.remove(this.review.rvid);
        console.log(response.data);
        this.$router.push("/review");
      } catch (error) {
        console.log(error);
      }
    },
  },

  mounted() {
    // 사용자 정보를 가져오고, 리뷰 상세 정보 가져오기
    this.getCurrentUser();
    this.getDetail(this.$route.params.rvid);
  },
};
</script>

<style></style>
