<template>
  <div>
    <!-- title -->
    <div class="form-floating mb-3">
      <input
        type="text"
        class="form-control"
        id="title"
        placeholder="title"
        v-model="notice.title"
      />
      <label for="title">title</label>
    </div>

    <!-- contents -->
    <div class="form-floating mb-3">
      <input
        type="text"
        class="form-control"
        id="contents"
        placeholder="contents"
        v-model="notice.contents"
      />
      <label for="contents">contents</label>
    </div>

    

    <!-- 수정 버튼 -->
    <button type="button" class="btn btn-warning me-2" @click="update">
      수정
    </button>

    <!-- 삭제 버튼 -->
    <button type="button" class="btn btn-danger" @click="remove">
      삭제
    </button>
  </div>
</template>
<script>
import NoticeService from "@/services/basic/NoticeService";
export default {
  data() {
    return {
      notice: {
        noid: "",
        title: "",  
        contents: "",
        imageUrl: "",
        writer: "ITN2024@gmail.com",
      },
    };
  },
  methods: {
    // 함수작성
    // TODO: 상세조회
    async getDetail(noid) {
      try {
        let response = await NoticeService.get(noid);
        console.log(response.data);
        this.notice = response.data;
      } catch (error) {
        console.log(error);
      }
    },
    // TODO: 수정
    async update() {
      try {
        // let temp = {
        //   dno: this.dept.dno,
        //   dname: this.dept.dname,
        //   loc: this.dept.loc,
        // };

        let response = await NoticeService.update(this.notice.noid,this.notice);
        console.log(response.data);  // 디버깅
        this.$router.push("/notice");  // 전체조회 강제이동: /dept
      } catch (error) {
        console.log(error);
      }
    },
    // TODO : 삭제
    async remove() {
      try {
        // let temp = {
        //   dno: this.dept.dno,
        //   dname: this.dept.dname,
        //   loc: this.dept.loc,
        // };

        let response = await NoticeService.remove(this.notice.noid, this.notice);
        console.log(response.data);
        this.$router.push("/notice");
      } catch (error) {
        console.log(error);
      }
    },
  },
  // 화면이 뜰때 실행하는 함수
  mounted() {
    // 상세조회 :dno(부서번호:기본키)값
    //TODO: 사용법) this.$route.params.변수명
    // => router/index.js: 메뉴등록 : /dept/:dno */
    this.getDetail(this.$route.params.noid);
  },
};
</script>
<style></style>
