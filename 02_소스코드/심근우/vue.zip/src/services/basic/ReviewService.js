// services - DeptService.js
import axios from "axios";
// 벡엔드 주소 : springboot 주소(컨트롤러주소)
const baseURL = "http://localhost:8000/api"

// TODO: 전체조회 : pageIndex(현재페이지번호), recordCountPerPage(화면에보일개수)
// TODO:           벡엔드로 요청 -> 벡엔드 sql 실행
// TODO: 사용법) axios.get(url);
const getAll = (searchKeyword,pageIndex, recordCountPerPage) => {
    return axios
       .get(baseURL+`/basic/review?searchKeyword=${searchKeyword}&pageIndex=${pageIndex}&recordCountPerPage=${recordCountPerPage}`);
};


// TODO: 상세조회(dno)
const get =(rvid)=>{
    return axios.get(baseURL+`/basic/review/${rvid}`);
    }


    // TODO: 부서수정
const update = (rvid, data) => {
    return axios.put(baseURL + `/basic/review/${rvid}`, data);
}


// TODO: 부서삭제
const remove = (rvid, data) => {
    return axios.delete(baseURL + `/basic/review/${rvid}`, data);
}
// TODO: 부서생성 : "/api/basic/dept"
// TODO:           json data(db에 생성될 객체)
// TODO: 사용법) axios.post(baseURL+`/basic/dept`,data);
const insert = (data) => {
    return axios.post(baseURL+`/basic/review`,data);
};




const ReviewService = {
     getAll,
     insert,
     get,
     update,
     remove
    };
export default ReviewService;

