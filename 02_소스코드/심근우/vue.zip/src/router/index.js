import { createRouter, createWebHistory } from 'vue-router'
import HomeView from '../views/HomeView.vue'

const routes = [
  {
    path: '/',
    component: HomeView
  },
  {
    // 부서 메뉴 등록 : path(/dept), component(DeptView.vue)
    path: '/notice',
    component: () => import('../views/basic/notice/NoticeView.vue')
  },
  {
    // 부서 메뉴 등록 : path(/add-dept), component(AddDept.vue)
    path: '/add-notice',
    component: () => import('../views/basic/notice/AddNotice.vue')
  },
  {
    // path(/dept/:dno), component(DeptDetail.vue)
    path: '/notice/:noid',
    component: () => import('../views/basic/notice/NoticeDetail.vue')
  },
  {
    path: '/review',
    component: () => import('../views/basic/review/ReviewView.vue')
  },
  {
    // path(/add-emp), component(AddEmp.vue)
    path: '/add-review',
    component: () => import('../views/basic/review/AddReview.vue')
  },
  {
    // path(/emp/:eno), component(EmpDetail.vue)
    path: '/review/:eno',
    component: () => import('../views/basic/review/ReviewDetail.vue')
  },
  
  {
    // path(/gallery), component(GalleryView.vue)
    path: '/cart',
    component: () => import('../views/advanced/cart/CartView.vue')
  },
  {
    // path(/add-gallery), component(AddGallery.vue)
    path: '/add-cart',
    component: () => import('../views/advanced/cart/AddCart.vue')
  },
  {
    // path(/fileDb/:uuid), component(FileDbDetail.vue)
    path: '/cart/:uuid',
    component: () => import('../views/advanced/cart/CartDetail.vue')
  },
]

const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes
})

export default router
